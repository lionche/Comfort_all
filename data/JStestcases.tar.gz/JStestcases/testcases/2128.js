function(b) {
    return Math.min(0, b);
}