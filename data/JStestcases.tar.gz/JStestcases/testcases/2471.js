function() {
    this.func.apply(this, arguments);
}