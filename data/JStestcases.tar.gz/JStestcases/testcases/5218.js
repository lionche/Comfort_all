function(method) {
    return !method.computed && !method.static && (
        (method.key.name === "constructor") || // Identifier
        (method.key.value === "constructor") // Literal
    );
}