function() {
    "use asm";

    function caller() {
        var a = 1.5;
        if ((~~(a + a)) == 3) {
            return 24;
        }
        return 0;
    }
    return {
        caller: caller
    };
}