function() {
    new Array.prototype.concat();
}