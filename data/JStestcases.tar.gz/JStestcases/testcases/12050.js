function(a) {
    return a.charAt(1) <= "b";
}