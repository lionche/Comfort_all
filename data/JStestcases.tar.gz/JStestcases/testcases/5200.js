function(data, encoding) {
    if (this._isGoaway()) return;
    if (data) this.write(data, encoding);
    this.emit('finish');
}