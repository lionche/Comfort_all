function(str) {
    eval("/" + str + "/.test('" + str + "').echo()");
}