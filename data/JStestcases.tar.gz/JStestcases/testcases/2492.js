function(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
}