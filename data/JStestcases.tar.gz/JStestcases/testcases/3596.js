function() {
    function foo(x) {
        return capture_me;
    }
    var capture_me;
}