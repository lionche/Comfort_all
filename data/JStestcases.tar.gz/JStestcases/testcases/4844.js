function(use) {
    return "(function() { " + use + " })()";
}