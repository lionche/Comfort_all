function(o, v) {
    o.x = v;
}