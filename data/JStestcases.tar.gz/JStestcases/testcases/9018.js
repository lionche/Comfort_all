function() {
    var x = -1;
}