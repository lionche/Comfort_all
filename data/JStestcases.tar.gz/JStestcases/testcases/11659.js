function() {
    var sequence = "";
    for (var a in [0, 1]) {
        L: do {
            for (var b in [2, 3, 4]) {
                continue L;
            }
        } while (false);
        sequence += a;
    }
    return sequence;
}