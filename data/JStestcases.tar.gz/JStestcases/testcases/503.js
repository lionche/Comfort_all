function() {
    debugger;
    Promise.resolve().then(v => v * 2);
}