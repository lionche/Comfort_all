function() {
    this.x = {};
}