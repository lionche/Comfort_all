function() {
    var o = new String("text");
    o.x = 4;
    o.y = 5;
    o.z = 6;
    return o;
}