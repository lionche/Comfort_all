function(n, v1, v2) {
    for (var i = 0; i < n; ++i) {
        var tmp = v1;
        v1 = v2;
        v2 = tmp;
    }
    return v1;
}