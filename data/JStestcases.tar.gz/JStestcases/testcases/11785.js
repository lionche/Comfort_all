function() {
    if (this.channel1totalLength > 1) {
        --this.channel1totalLength;
    } else if (this.channel1totalLength == 1) {
        this.channel1totalLength = 0;
        this.channel1EnableCheck();
        this.memory[0xFF26] &= 0xFE; //Channel #1 On Flag Off
    }
    if (this.channel2totalLength > 1) {
        --this.channel2totalLength;
    } else if (this.channel2totalLength == 1) {
        this.channel2totalLength = 0;
        this.channel2EnableCheck();
        this.memory[0xFF26] &= 0xFD; //Channel #2 On Flag Off
    }
    if (this.channel3totalLength > 1) {
        --this.channel3totalLength;
    } else if (this.channel3totalLength == 1) {
        this.channel3totalLength = 0;
        this.channel3EnableCheck();
        this.memory[0xFF26] &= 0xFB; //Channel #3 On Flag Off
    }
    if (this.channel4totalLength > 1) {
        --this.channel4totalLength;
    } else if (this.channel4totalLength == 1) {
        this.channel4totalLength = 0;
        this.channel4EnableCheck();
        this.memory[0xFF26] &= 0xF7; //Channel #4 On Flag Off
    }
}