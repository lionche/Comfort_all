function(s) {
    return "async function test() { " + s + "}";
}