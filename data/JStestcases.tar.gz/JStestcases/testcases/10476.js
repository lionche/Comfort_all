function() {
    while (0) continue;
}