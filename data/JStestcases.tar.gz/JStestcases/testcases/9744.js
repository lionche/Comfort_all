function() {
    for (var i = 0; i < 50000; ++i) Math.random();
}