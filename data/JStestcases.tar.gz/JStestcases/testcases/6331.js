function() {
    var p1 = 5;
    (eval)("assert(p1 === 5)");
}