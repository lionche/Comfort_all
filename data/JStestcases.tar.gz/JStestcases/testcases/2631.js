function() {
    Array.from([1]).concat([2]).map(v => v * 2);
}