function() {
    return 'hello world';
}