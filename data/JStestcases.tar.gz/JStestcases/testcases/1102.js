function(text) {
    return text.replace(/<a[^>]*>/g, "").replace(/<\/a>/g, "");
}