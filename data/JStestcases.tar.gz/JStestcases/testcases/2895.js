function() {
    try {
        throw "early-throw";
    } finally {
        throw "override";
    }
}