function(arg) {
    return arg[0];
}