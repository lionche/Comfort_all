function(x) {
    ' + varbinds[v] + '
}