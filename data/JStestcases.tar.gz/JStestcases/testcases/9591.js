function() {
    var c;
    for (c in []) {}
}