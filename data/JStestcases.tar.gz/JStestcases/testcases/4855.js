function() {
    this.waiting = [];
    this.locked = false;
    this.id = this._nextId();
}