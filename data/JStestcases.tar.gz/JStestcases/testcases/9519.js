function() {
    var a = 0;
    while (!(a < 1 || a < 1))
        return true;
    return false;
}