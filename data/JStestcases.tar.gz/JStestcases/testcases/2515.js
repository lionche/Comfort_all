function() {
    for (var h = 0; h < 1; ++h) {
        for (var r = 0; r < 1; ++r) {
            var a = r;
        }
    }
}