function() {
    if (this.checksum != this.cumulative_checksum) {
        throw new Error("Wrong checksum.");
    }
    this.cumulative_checksum = 0;
}