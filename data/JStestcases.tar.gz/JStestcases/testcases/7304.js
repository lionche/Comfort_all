function(w) {
    var a = [], // The array holding the partial texts.
        i, // Loop counter.
        l = this.length,
        v; // The value to be stringified.
    for (i = 0; i < l; i += 1) {
        v = this[i];
        switch (typeof v) {
            case 'object':
                if (v && typeof v.toJSONString === 'function') {
                    a.push(v.toJSONString(w));
                } else {
                    a.push('null');
                }
                break;
            case 'string':
            case 'number':
            case 'boolean':
                a.push(v.toJSONString());
                break;
            default:
                a.push('null');
        }
    }
    return '[' + a.join(',') + ']';
}