function(chr) {
    return chr >= 48 && chr <= 57;
}