function() {
    return 12345;
}