function(text) {
    this.writeToOutput(text);
}