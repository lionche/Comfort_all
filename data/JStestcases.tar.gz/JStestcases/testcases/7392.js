function() {
    var x;
    return typeof x;

    function x() {
        return 7;
    }
}