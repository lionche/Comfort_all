function() {
    'ground control to major tom'
}