function(port) {
    this.port = port;
}