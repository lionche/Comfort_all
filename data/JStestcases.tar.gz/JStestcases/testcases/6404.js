function() {
    'use strict';
    debugger; // Break 0.
    var i = 0; // Break 1.
    i++; // Break 2.
    i++; // Break 3.
    debugger; // Break 4.
    return i // Break 5.
    ; // Break 6.
}