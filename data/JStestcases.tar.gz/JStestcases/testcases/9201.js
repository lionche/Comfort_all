function(x) {
    return x ^ 100;
}