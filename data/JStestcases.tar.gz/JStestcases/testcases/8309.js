function(a) {
    return a !== 0;
}