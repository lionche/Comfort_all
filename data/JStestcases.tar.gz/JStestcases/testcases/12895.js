function(a) {
    return Math.min(a, 0);
}