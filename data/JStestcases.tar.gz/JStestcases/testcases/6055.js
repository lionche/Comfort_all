function() {
    throw "invalof"
}