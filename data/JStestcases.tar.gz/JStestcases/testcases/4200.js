function(buffer) {
    if (this.noReturn) {
        this.outputBuffer = buffer;
        return buffer.length;
    } else {
        return buffer;
    }
}