function(a) {
    return this * (a * a + a);
}