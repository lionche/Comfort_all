function(sab) {
    var ui8 = new Uint8Array(sab);
    for (var i = 0; i < sab.byteLength; ++i) {
        ui8[i] = 0;
    }
}