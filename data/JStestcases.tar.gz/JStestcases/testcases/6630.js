function() {
    throw "MyError"
}