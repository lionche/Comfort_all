function(el, bgColor) {
    var borderValue = "1px solid " + this._borderColor(bgColor);
    var borderL = "border-left: " + borderValue;
    var borderR = "border-right: " + borderValue;
    var style = "style='" + borderL + ";" + borderR + "'";
    el.innerHTML = "<div " + style + ">" + el.innerHTML + "</div>";
}