function*() {
    yield 0;
}