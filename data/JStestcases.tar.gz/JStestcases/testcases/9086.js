function() {
    var s = new Set();
    s.values.call(Set.prototype);
}