function(array) {
    function t(a, b, c) {
        return arguments.length;
    }
    delete array[1];
    return t.apply(null, array);
}