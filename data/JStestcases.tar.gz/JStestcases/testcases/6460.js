function() {
    throw "stop_long_loop";
}