function(x) {
    return x;

    function x() {
        return 7;
    }
}