function(parentObj) {
    "use strict";
    parentObj.registerC = parentObj.registerE;
}