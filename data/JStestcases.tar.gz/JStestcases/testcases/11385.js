function() {
    var o = [0, 1, 2, 3];
    Object.defineProperty(o, 1, {
        get: function() {
            return "getter1";
        }
    });
    return o;
}