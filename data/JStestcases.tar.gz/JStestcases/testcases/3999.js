function(a, b) {
    var x = 0;
    if (a.f < b.f) {
        var result = b.g - a.g;
        x = !x;
        return result;
    } else {
        var result = a.g - b.g;
        x = [x];
        return result;
    }
}