function(array, searchValue) {
    return array.indexOf(searchValue) !== -1;
}