function(keyword) {
    try {
        eval("var x = <foo " + keyword + "='idref'/>;\n\
                    if (x.@" + keyword + " != 'idref')\n\
                      throw 'keywords on the right of the @ E4X selector are broken!';");
    } catch (e) {
        throw e;
    }
}