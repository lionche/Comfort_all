function(a, b, v) {
    return a[b] = 0
}