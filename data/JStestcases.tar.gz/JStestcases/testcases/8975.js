function() {
    "use asm";

    function __f_20() {
        var __v_23 = 1;
        if ((+((__v_23 + __v_23) | 0)) > 1.5) {
            return 25;
        }
        return 0;
    }
    return {
        __f_20: __f_20
    };
}