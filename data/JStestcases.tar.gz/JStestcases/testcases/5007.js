function() {
    var obj = {};
    var victim = 'PASS';
    obj.__defineSetter__('slot',
        function(v) {
            victim = 'FAIL';
        });
    var obj2 = {};
    obj2.forward = (obj['slot'] = victim);
    return obj2.forward;
}