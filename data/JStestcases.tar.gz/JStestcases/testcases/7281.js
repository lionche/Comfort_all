function() {
    try {} catch {}
}