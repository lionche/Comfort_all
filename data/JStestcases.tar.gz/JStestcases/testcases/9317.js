function(value) {
    this.value = value;
    this.toString = new Function("return this.value+''");
    return this;
}