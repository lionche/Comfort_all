function(matched, offset, string) {
    return 'XYZ';
}