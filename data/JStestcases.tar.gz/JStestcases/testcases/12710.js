function() {
    return arguments.constructor.prototype;
}