function(fields, options) {
    fields.year -= 1911;
    return this.iso8601.dateFromFields(fields, options);
}