function() {
    return 'toJSON';
}