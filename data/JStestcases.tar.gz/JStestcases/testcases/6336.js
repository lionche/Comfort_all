function() {
    throw "intostr";
}