function() {
    var a = 0.1;
    var i = 0.1;
    do {
        if (i > 0.1)
            return true;
        i++;
    } while (!(a <= 1.1 && a <= 1.1))
    return false;
}