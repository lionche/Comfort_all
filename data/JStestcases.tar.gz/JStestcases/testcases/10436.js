function() {
    var x = 1; /**bp:dumpFunctionProperties(0, 1);**/
}