function() {
    var jQuery = function(a, b) {
        return jQuery && jQuery.length;
    }
    return jQuery();
}