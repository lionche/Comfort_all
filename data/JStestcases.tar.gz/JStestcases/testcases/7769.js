function(delayInSamples) {
    this.delayInSamples = delayInSamples;
    this.delayInputPointer = this.delayOutputPointer + delayInSamples;
    if (this.delayInputPointer >= this.delayBufferSamples.length - 1)
        this.delayInputPointer = this.delayInputPointer - this.delayBufferSamples.length;
}