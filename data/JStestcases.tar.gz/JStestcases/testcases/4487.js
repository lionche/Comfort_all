function(writeOrDisplay) {
    if (this.length === 0) return "#()";
    var res = "#(" + writeOrDisplay(this[0]);
    for (var i = 1; i < this.length; i++)
        res += " " + writeOrDisplay(this[i]);
    res += ")";
    return res;
}