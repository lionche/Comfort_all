function(parentObj, address, data) {
    parentObj.ROMBank1offs = data & 0x0F;
    parentObj.setCurrentMBC2AND3ROMBank();
}