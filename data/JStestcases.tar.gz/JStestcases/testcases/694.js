function(first, second) {
    first += second;
}