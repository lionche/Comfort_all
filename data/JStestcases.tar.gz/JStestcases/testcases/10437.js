function(a) {
    return arguments;
}