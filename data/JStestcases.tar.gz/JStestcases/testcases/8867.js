function(x) {
    eval.call(null, x)
}