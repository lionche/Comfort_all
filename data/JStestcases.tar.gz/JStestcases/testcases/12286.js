function(a, i) {
    a[i] = "bazinga!";
}