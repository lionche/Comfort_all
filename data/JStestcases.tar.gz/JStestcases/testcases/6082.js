function() {
    Function.prototype.bind.call(true);
}