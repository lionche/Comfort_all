function(val, idx, obj) {
    return new Boolean(false);
}