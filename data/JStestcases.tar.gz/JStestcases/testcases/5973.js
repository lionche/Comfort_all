function() {
    var key0 = {};
    var key1 = {};
    var map0 = new WeakMap();
    var map1 = new WeakMap();
    map0.set(key0, key1);
    map0.set(key1, {
        y: 17
    });
    map1.set({}, {});
    map1.prop = key0;
    return [map1, map0];
}