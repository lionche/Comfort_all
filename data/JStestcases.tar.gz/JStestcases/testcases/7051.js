function(stdlib, foreign, buffer) {
    "use asm";
    var fround = stdlib.Math.fround;
    var a = 2.0;
    const b = 1.0;
    var c = fround(1.0);
    const d = fround(2);

    function f1() {
        c = d < c ? c : d;
        return fround(c);
    }
    return {
        f1: f1
    };
}