function(d, e, s) {
    this.description = d;
    this.whileExpression = e;
    this.statements = s;
}