function() {
    var a = 2;
    debugger;
    debugger;
}