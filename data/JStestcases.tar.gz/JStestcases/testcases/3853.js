function() {
    return ["PASSED", {
        e: "PASSED",
        get f() {
            throw "PASSED";
        }
    }, "FAILED"];
}