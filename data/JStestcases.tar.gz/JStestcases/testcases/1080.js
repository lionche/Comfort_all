function(parts) {
    return parts.map(x => x.value).join("");
}