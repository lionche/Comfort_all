function(constructor, testMethod) {
    testMethod["1"]("(1 instanceof " + constructor + ")");
    testMethod["{}"]("({} instanceof " + constructor + ")");
    testMethod["obj"]("(obj instanceof " + constructor + ")");
}