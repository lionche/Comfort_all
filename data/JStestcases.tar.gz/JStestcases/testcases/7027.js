function* opt() {
    for (;;)
        if (true) {} else {
            yield;
        }
    for (;;)
        if (true) {} else {
            yield;
        }
}