function() {
    var literal = [1, 2, 3];
    return literal;
}