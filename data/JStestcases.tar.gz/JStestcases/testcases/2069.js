function() {
    return "Motion(" + this.callsign + " from " + this.posOne + " to " + this.posTwo + ")";
}