function() {
    var i = 10;
    var a = new String("foo");
    for (var j = 0; j < i; j++) {
        a[j] = {};
    }
}