function() {
    return "protoString";
}