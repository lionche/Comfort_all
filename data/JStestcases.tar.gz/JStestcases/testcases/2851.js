function(value) {
    this.value = value;
    this.generation = "A";
    this.toString = new Function("return \"(instance of Gen\"+this.generation+\")\"");
}