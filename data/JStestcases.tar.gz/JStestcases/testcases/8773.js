function() {
    var o = {
        a: 0
    };
    for (var i = 0; i < 1; ++i) {
        o.a &= 1;
        for (var j = 0; j < 1; ++j)
            o.a = 1;
    }
    return o.a;
}