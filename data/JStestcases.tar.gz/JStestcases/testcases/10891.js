function(parentObj) {
    "use strict";
    parentObj.registerE |= 0x02;
}