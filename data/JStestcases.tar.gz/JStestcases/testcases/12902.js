function(arg5) {
    var string = "that: " + this.that5 + ", arg: " + arg5;
    return string;
}