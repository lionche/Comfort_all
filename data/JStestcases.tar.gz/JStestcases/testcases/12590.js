function(x) {
    x = x | 0;
    if (x == 0) return;
    return x;
}