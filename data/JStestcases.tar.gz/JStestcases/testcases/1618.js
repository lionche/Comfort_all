function(a) {
    if (a != null && a != void 0)
        return a;
    else
        return 0;
}