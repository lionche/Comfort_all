function(parentObj) {
    "use strict";
    parentObj.registerA = parentObj.registerB;
}