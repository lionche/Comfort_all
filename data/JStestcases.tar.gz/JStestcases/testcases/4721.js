function(a) {
    throw Error("deep stack");
}