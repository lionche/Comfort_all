function(v) {
    throw 42;
}