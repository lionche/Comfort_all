function(parentObj) {
    parentObj.FCarry = ((parentObj.registerC & 0x01) == 0x01);
    parentObj.registerC = (parentObj.registerC & 0x80) | (parentObj.registerC >> 1);
    parentObj.FHalfCarry = parentObj.FSubtract = false;
    parentObj.FZero = (parentObj.registerC == 0);
}