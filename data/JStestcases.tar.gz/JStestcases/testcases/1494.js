function(value) {
    switch (value) {
        case 0:
            return 291;
        case -5:
            return 5;
        case -4:
        case -0:
            return 313;
        case -3:
            return 3;
        case -2:
            return 1;
        case -1:
            return 10;
    }
    return 0;
}