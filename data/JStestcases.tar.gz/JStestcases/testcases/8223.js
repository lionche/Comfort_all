function(p2, p3) {
    return ((p3 + (p3 = p2 * p2)));
}