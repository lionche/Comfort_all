function(parentObj) {
    parentObj.FCarry = ((parentObj.registersHL & 0x0100) == 0x0100);
    parentObj.registersHL = ((parentObj.registersHL >> 1) & 0xFF00) | (parentObj.registersHL & 0xFF);
    parentObj.FHalfCarry = parentObj.FSubtract = false;
    parentObj.FZero = (parentObj.registersHL < 0x100);
}