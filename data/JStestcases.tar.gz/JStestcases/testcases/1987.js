function(parentObj) {
    parentObj.FCarry = ((parentObj.registerA & 0x01) == 0x01);
    parentObj.registerA = (parentObj.registerA & 0x80) | (parentObj.registerA >> 1);
    parentObj.FHalfCarry = parentObj.FSubtract = false;
    parentObj.FZero = (parentObj.registerA == 0);
}