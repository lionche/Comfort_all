function(o) {
    switch (o) {
        case String:
        case 1:
            return "";
    }
}