function(x) {
    var a = new Array(1);
    a[0] = x;
    return a;
}