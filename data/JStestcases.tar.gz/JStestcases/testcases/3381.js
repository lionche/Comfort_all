function(a, b, o1, o2) {
    o1 + o2;
    return a <= b;
}