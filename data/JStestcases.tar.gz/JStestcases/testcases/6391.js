function() {
    throw "My Super Error E";
}