function(x, r) {
    x.squareTo(r);
    this.reduce(r);
}