function() {
    return Array.prototype.push(1), Object.freeze(Array.prototype);
}