function(x) {
    return '(' + x.toString() + ')';
}