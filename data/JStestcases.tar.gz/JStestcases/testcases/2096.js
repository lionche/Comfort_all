function(n, r) {
    var this_array = this.array;
    var r_array = r.array;
    for (var i = n; i < this.t; ++i) r_array[i - n] = this_array[i];
    r.t = Math.max(this.t - n, 0);
    r.s = this.s;
}