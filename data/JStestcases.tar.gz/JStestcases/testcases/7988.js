function() {
    function middle() {
        function inner() {
            return x;
        }
        eval("1 + 1");
        return x + inner();
    }
    let x = 1;
    return middle();
}