function() {
    return 'exported';
}