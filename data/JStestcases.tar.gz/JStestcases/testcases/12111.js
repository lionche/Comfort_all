function() {
    "use asm";

    function inc1(x) {
        x = x | 0;
        return (x + 1) | 0;
    }

    function inc2(x) {
        x = x | 0;
        return (x + 2) | 0;
    }

    function caller() {
        var i = 0,
            j = 1;
        if ((function_table[i & 1](50) | 0) == 51) {
            if ((function_table[j & 1](60) | 0) == 62) {
                return 73;
            }
        }
        return 0;
    }
    var function_table = [inc1, inc2]
    return {
        caller: caller
    };
}