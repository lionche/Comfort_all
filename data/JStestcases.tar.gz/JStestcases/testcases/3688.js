function(obj) {
    let result = "";
    for (let prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            result += `own: ${prop}, `;
        } else {
            result += `not: ${prop}, `;
        }
        delete obj.x;
    }
    return result;
}