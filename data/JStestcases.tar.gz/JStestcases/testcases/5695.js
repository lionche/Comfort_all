function() {
    return "$`$&$'";
}