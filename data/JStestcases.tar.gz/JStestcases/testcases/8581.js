function() {
    new Map([1]);
}