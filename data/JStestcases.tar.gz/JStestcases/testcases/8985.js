function(val, Idx, obj) {
    if (arguments.length === 3) //verify if callbackfn was called with 3 parameters
        return true;
}