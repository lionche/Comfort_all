function /*A*/ /*B*/( /*C*/ a /*D*/ , /*E*/ b /*G*/ ) /*H*/ {
    /*I*/ }