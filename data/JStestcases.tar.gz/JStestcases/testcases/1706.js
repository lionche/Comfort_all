function() {
    let x = 1;
}