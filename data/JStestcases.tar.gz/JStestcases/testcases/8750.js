function(arg) {
    return (arg instanceof Number) && (arg >= 0);
}