function() {
    RegExp("(?!.){1,}", "u");
}