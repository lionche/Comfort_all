function(name, dept) {
    this.name = name || "";
    this.dept = dept || "general";
}