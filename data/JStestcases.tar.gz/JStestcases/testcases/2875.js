function(array, sum) {
    sum += array[0] = 1;
    sum += array[1] = 2;
    sum += array[2] = 3;
    return sum;
}