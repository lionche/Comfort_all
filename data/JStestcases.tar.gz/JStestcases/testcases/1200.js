function() {
    return "hello";
}