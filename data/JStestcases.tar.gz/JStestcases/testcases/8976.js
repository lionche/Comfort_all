function() {
    throw ReferenceError("")
}