function(x) {
    (function() {
        x;
    });
}