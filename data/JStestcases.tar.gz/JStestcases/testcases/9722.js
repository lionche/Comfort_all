function() {
    Reflect.setPrototypeOf({}, undefined);
}