function(stack) {
    return stack[stack.length - 1];
}