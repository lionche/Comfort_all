function(arg) {
    this.prop = arg;
}