function() {
    return {
        next: function() {
            return {
                done: false
            };
        },
        return: function() {
            return 23;
        }
    };
}