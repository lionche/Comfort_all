function() {
    throw new Error("caught");
}