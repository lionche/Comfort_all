function(x, y, z) {
    return typeof(x, y);
}