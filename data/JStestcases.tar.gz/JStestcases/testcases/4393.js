function() {
    Date.prototype.getTime.call(0)
}