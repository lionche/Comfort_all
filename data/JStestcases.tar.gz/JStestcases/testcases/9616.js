function(obj, prop) {
    return obj[prop] = undefined
}