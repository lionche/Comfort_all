function() {
    return {
        start: 0,
        end: 128,
        test: function(a, src) {
            let x = 0;
            for (let i = 0; i < 128; i++) {
                let m = src[i];
                x += m;
                a[i] = m;
            }
            return x;
        }
    };
}