function(s) {
    this.res += s;
}