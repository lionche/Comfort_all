function() {
    typeof D;
}