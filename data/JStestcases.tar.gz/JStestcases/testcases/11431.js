function() {
    return 0.0;
}