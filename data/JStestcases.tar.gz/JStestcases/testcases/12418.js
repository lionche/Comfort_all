function(a) {
    return 'second';
}