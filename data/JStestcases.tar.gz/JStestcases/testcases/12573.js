function() {
    JSON.parse();
}