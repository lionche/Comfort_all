function() {
    var a2 = -1756315459;
    return ((((a2 & a2) ^ 1) * a2) << -10);
}