function(a, b) {
    return a + 0x7fffffff & b | a;

    function test0slota() {
        a;
    }
}