function(stdlib, imports) {
    "use asm";
    var imp = imports.imp;

    function bar() {}
    return {
        bar: bar
    };
}