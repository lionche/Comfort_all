function(name, data, ownerDocument) {
    this.tagName = this.nodeName = name.toUpperCase();
    this.ownerDocument = ownerDocument || null;
    if (name == "DOCUMENT") {
        this.nodeType = 9;
        this.childNodes = [];
    } else if (typeof(data) == "string") {
        this.nodeValue = data;
        this.nodeType = 3;
    } else {
        this.nodeType = 1;
        this.childNodes = [];
    }
    if (name.substring(0, 1) == "<") {
        var nameattr = name.substring(
            name.indexOf('"') + 1, name.lastIndexOf('"'));
        name = name.substring(1, name.indexOf(" "));
        this.tagName = this.nodeName = name.toUpperCase();
        this.setAttribute("name", nameattr);
    }
}