function(o, p) {
    var x = o.f;
    if (p)
        o = null;
    return x + o.g();
}