function() {
    var a = 1;
    var b = 2;
    var eval = 5; // Overriding eval should not break anything.
    debugger; // Breakpoint.
    return a;
}