function() {
    return ['a', 'b', 'c'];
}