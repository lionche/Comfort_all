function(parentObj) {
    "use strict";
    parentObj.registerB = parentObj.registersHL >> 8;
}