function() {
    var level1Var = {
        prop: 1
    };

    function FuncLevel2() {
        var level2Var = {
            prop: 1
        };

        function FuncLevel3() {
            var localVar1 = level1Var;
            var localVar2 = level2Var; /**bp:locals(1);**/
        }
        FuncLevel3();
    }
    FuncLevel2();
}