function(parentObj) {
    "use strict";
    parentObj.registerE &= 0xBF;
}