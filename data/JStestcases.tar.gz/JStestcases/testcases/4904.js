function() { // null dummy scope
    try {
        throw -1;
    } catch (e1) { // catch scope
        e1;
        (function g() {
            e1;
            /**bp:stack();locals(1)**/
        })();
    }
}