function(a1) {
    return a1[0];
}