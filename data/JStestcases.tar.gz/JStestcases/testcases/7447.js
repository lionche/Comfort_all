function() {
    return () => eval("this");
}