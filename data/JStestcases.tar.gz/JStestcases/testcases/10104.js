function(val, idx, obj) {
    return val === 11 && idx === 0;
}