function() {
    "use strict";
    return this ? this.name : "u";
}