function(a) {
    return Math.min(a, false);
}