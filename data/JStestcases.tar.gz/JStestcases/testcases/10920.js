function(value, msg) {
    if (!value) {
        throw new Error("Failed: " + msg);
    }
}