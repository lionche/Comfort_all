function(f) {
    return f.substr(f.lastIndexOf(".", f.length) + 1, f.length);
}