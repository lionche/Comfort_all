function() {
    return ['a', 'b']; // make a non-enumerable and b enumerable
}