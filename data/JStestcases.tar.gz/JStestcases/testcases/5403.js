function(array, value) {
    array.push(value);
}