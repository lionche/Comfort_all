function() {
    for (var a = 0.1; !(a < 1.1 || a < 1.1);)
        return true;
    return false;
}