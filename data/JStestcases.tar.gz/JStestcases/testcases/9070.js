function(obj1, obj2) {
    let result = "";
    for (let prop in obj1) {
        if (obj2.hasOwnProperty(prop)) {
            result += `own: ${prop}, `;
        } else {
            result += `not: ${prop}, `;
        }
    }
    return result;
}