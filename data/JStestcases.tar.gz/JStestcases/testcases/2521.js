function(a) {
    return a === "";
}