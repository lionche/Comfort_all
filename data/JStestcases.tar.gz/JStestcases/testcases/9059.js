function(a) {
    return a > 0.0;
}