function() {
    try {
        throw new Error();
    } catch (_) {}
}