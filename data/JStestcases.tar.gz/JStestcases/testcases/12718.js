function() {
    var i = 30;
    i++; /**bp:evaluate("var k = i; eval('k')")**/
}