function(parent, name) {
    return parent.node_ops.lookup(parent, name);
}