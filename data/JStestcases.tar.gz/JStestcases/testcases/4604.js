function(base) {
    class klass extends base {
        constructor() {
            try {
                undefined();
            } catch (e) {}
            super();
            this.d = 4.2;
            this.o = {};
        }
    }
    var __v_58 = new klass();
    var __v_59 = new klass();
}