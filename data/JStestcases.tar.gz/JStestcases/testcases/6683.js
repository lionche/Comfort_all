function(obj, value) {
    return obj.setterProperty = value;
}