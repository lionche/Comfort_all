function(str) {
    try {
        eval(str);
    } catch (e) {
        return e instanceof RangeError;
    }
    return false;
}