function(__v_8) {
    var __v_9 = "mod_";
    var __v_10 = eval(
        'function Module(stdlib, foreign, heap) {\n' +
        ' "use asm";\n' +
        ' function ' + __v_9 + '(dividend) {\n' +
        '  dividend = dividend | 0;\n' +
        '  return ((dividend | 0) % ' + __v_8 + ') | 0;\n' +
        ' }\n' +
        ' return { f: ' + __v_9 + '}\n' +
        '}; Module');
    return __v_10().f;
}