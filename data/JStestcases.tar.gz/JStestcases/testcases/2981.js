function() {
    Function.prototype.apply.call(null, {}, []);
}