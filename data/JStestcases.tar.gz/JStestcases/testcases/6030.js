function() {
    RegExp("[\\9]", "u");
}