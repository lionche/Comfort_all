function() {
    "use asm";

    function __f_20() {
        label: {
            if (1) break label;
            return 11;
        }
        return 12;
    }
    return {
        __f_20: __f_20
    };
}