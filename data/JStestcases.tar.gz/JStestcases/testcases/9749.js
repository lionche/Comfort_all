function(value) {
    this.value = value;
    this.generation = "B";
    this.toString = new Function("return \"(instance of Gen\"+this.generation+\")\"");
}