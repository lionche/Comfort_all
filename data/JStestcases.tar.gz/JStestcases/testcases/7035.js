function() {
    RegExp("(?=.){1,2}?", "u");
}