function(...args) {
    eval("var arguments = 1;");
}