function* g3() {
    yield 1;
    yield 2;
}