function(a) {
    return a <= -2147483648;
}