function() {
    this.toString = function() {
        return 42;
    };
    this.charCodeAt = String.prototype.charCodeAt;
}