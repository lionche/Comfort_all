function() {
    throw new ReferenceError('foo')
}