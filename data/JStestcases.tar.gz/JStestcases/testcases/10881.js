function(v1, n) {
    var v2 = 0;
    var v3 = -6;
    for (var i = 0; i < n; ++i) {
        v2 = v3;
        v1[v3];
        v3 = v2;
    }
}