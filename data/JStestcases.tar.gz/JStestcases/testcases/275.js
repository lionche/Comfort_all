function(x) {
    return x--;
}