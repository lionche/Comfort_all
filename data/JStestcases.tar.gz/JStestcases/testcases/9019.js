function(receiver, args) {
    return Function.prototype.apply.call(this, receiver, args);
}