function(val, idx, obj) {
    return val < 3 ? true : false;
}