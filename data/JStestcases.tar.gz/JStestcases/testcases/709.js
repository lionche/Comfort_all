function(msg) {
    return Error(msg);
}