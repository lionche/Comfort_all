function(maxDelayInSamplesSize, delayInSamples, masterVolume, delayVolume) {
    this.delayBufferSamples = new Array(maxDelayInSamplesSize); // The maximum size of delay
    this.delayInputPointer = delayInSamples;
    this.delayOutputPointer = 0;
    this.delayInSamples = delayInSamples;
    this.masterVolume = masterVolume;
    this.delayVolume = delayVolume;
}