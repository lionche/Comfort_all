function() {
    return 'invalid';
}