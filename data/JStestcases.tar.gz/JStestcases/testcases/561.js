function() {
    var a = {
        constructor: true
    };
    debugger;
}