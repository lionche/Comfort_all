function(constr, numElements) {
    var sab = new SharedArrayBuffer(constr.BYTES_PER_ELEMENT * numElements);
    return new constr(sab);
}