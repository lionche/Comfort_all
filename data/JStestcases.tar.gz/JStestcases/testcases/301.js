function() {
    var o = new Date("2013/12/03");
    o.x = 4;
    o.y = 5;
    o.z = 6;
    return o;
}