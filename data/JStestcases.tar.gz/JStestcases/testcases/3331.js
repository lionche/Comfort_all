function() {
    ({
        a = ([arguments]) => {}
    } = 1);
    arguments.x;
}