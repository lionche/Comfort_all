function(a, b, c) {
    this.a = a;
    this.b = b;
    this.c = c;
    throw this;
}