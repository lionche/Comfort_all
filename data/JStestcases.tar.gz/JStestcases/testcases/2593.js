function() {
    let opt, arr = [...[...[...[...new Uint8Array(0x10000)]]]];
    while (arr--) {
        opt = ((typeof opt) === 'undefined') ? /a/ : arr;
    }
}