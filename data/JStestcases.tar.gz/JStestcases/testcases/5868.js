function(f, array, i) {
    return f(array[i]);
}