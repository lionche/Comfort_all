function() {
    " + tests[test] + ";
}