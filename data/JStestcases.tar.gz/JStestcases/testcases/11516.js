function() {
    return 'invalid'
}