function(p) {
    return p.cdr;
}