function(a, b) {
    a *= 2;
    b *= 2;
    if (a < 1 && b < 1) {
        return a * b;
    }
}