function(numSamples) {
    if (this.soundMasterEnabled && !this.CPUStopped) {
        for (var samplesToGenerate = 0; numSamples > 0;) {
            samplesToGenerate = (numSamples < this.sequencerClocks) ? numSamples : this.sequencerClocks;
            this.sequencerClocks -= samplesToGenerate;
            numSamples -= samplesToGenerate;
            while (--samplesToGenerate > -1) {
                this.computeAudioChannels();
                this.currentBuffer[this.audioIndex++] = this.mixerOutputCache;
                if (this.audioIndex == this.numSamplesTotal) {
                    this.audioIndex = 0;
                    this.outputAudio();
                }
            }
            if (this.sequencerClocks == 0) {
                this.audioComputeSequencer();
                this.sequencerClocks = 0x2000;
            }
        }
    } else {
        while (--numSamples > -1) {
            this.currentBuffer[this.audioIndex++] = 0xF0F0;
            if (this.audioIndex == this.numSamplesTotal) {
                this.audioIndex = 0;
                this.outputAudio();
            }
        }
    }
}