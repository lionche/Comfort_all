function() {
    eval('initial = x; delete x; postDeletion = function() { x; }; var x;');
}