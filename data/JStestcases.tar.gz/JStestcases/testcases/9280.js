function() {
    [].length = 4294967296;
}