function(use) {
    return "const c = 1, x = (" + use + ");"
}