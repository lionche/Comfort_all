function() {
    if (this.index < this.entryCount - 1) {
        this.index++
    } else {
        this.index = 0;
    }
}