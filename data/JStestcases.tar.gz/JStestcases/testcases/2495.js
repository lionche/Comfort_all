function() {
    for (let [{
            x
        }] of [
            [null]
        ]) {
        return;
    }
}