function() {
    new WeakSet([]);
}