function(v) {
    var o = {};
    o.a = v;
    return o;
}