function(onResolve, onReject) {
    return onResolve('resolved');
}