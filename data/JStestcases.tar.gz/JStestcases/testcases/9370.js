function(n /* = 1 */ ) {
    if (arguments.length === 0) {
        n = 1;
    }
    return function() {
        return n++;
    };
}