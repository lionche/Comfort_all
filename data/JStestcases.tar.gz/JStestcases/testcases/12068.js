function(pr, pk) {
    return function(k, d) {
        throw "myexn"
    }
}