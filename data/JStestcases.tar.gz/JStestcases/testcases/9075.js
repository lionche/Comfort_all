function() {
    throw new RangeError();
}