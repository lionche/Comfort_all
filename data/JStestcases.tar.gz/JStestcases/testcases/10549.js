function() {
    this.THIS = this
}