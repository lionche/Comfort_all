function(use) {
    return "eval(\"" + use + "\")";
}