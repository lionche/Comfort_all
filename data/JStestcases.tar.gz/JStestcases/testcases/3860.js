function() {
    let x = 20;
    const y = 30;
    return x + y;
}