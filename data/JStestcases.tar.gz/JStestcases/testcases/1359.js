function() {
    var o = new Number();
    o.x = 4;
    o.y = 5;
    o.z = 6;
    return o;
}