function(s) {
    /*
    var re = new RegExp("%d", "g");
    var args = arguments;
    var i = 0;
    print(s.replace(re, function() { return args[++i] }));
    */
}