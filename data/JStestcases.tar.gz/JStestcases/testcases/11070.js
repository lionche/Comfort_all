function() {
    return arguments;
}