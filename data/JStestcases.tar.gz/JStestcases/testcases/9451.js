function(a, b) {
    a = +a;
    b = +b;
    if (+a < +b) {
        return 1;
    }
    return 0;
}