function(v) {
    return new Promise((resolve, _) => resolve(v));
}