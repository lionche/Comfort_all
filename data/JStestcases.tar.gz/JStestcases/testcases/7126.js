function(str) { // escape control chars which might cause problems handling ciphertext
    return str.replace(/[\n\0\n\t\n\v\n\f\n\r\n\xa0'"!-]/g, function(c) {
        return '!' + c.charCodeAt(0) + '!';
    });
}