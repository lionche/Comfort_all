function() {
    (() => this); // bind this.
    function y() {
        (() => {
            (() => this); // bind this.
            debugger; // Y
        })(); // Y
    }
    y.call("Y"); // X
}