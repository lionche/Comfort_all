function(parentObj) {
    "use strict";
    var opcode = parentObj.memoryReader[parentObj.programCounter](parentObj, parentObj.programCounter);
    parentObj.programCounter = (parentObj.programCounter + 1) & 0xFFFF;
    parentObj.CPUTicks += parentObj.SecondaryTICKTable[opcode];
    parentObj.CBOPCODE[opcode](parentObj);
}