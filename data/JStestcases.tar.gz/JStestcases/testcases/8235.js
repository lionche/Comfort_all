function(x, y) {
    return x * y | 0;
}