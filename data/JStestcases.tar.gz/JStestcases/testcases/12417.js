function* gen(a, b) {
    debugger;
    yield a;
    yield b;
}