function() {
    return 1 && 2;
}