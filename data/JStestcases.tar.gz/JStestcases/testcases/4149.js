function(e, frames) {
    return frames;
}