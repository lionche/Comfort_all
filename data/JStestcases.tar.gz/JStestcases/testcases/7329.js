function(x) {
    x &= 15;
    if (x < 10) {
        return String.fromCharCode(x + 48);
    } else {
        return String.fromCharCode(x + 97 - 10);
    }
}