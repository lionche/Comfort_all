function(parentObj) {
    parentObj.registerD = parentObj.registerA;
}