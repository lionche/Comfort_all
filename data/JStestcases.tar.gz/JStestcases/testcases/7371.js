function() {
    L: {
        try {} finally {
            break L;
        }
    }
}