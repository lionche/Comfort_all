function(parentObj) {
    "use strict";
    parentObj.registerE &= 0xEF;
}