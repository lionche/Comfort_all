function(func) {
    return {
        __proto__: func(),
        a: 2,
        b: 3
    };
}