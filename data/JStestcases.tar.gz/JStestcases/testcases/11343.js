function(parentObj) {
    var H = ((parentObj.registersHL >> 8) - 1) & 0xFF;
    parentObj.FZero = (H == 0);
    parentObj.FHalfCarry = ((H & 0xF) == 0xF);
    parentObj.FSubtract = true;
    parentObj.registersHL = (H << 8) | (parentObj.registersHL & 0xFF);
}