function() {
    for (var i = 10; i >= 5; i--) {
        if (i < 0) return false;
        if (i === 5) return true;
    }
    return false;
}