function() {
    let x = 3;
    x++;
    x;
}