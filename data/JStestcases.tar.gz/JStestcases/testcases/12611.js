function(_length) {
    Object.defineProperty(this, "0", {
        set: function(_value) {},
        configurable: false,
    });
}