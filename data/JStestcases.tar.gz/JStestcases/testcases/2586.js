function() {
    String.prototype.startsWith.apply(undefined);
}