function() {
    return this.asHSL().b > 0.5;
}