function(x) {
    return x % 3;
}