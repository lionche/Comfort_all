function() {
    Object.defineProperty(null, "foo", {});
}