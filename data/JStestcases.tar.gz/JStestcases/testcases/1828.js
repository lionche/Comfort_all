function() {
    {
        let x = 1;
    }
    eval('var x');
}