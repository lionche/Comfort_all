function() {
    new WeakSet([1]);
}