function(s) {
    return s.replace(/\s/g, '');
}