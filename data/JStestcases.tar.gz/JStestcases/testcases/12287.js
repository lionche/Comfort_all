function() {
    return void 0 == undefined;
}