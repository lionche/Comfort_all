function(n, f) {
    for (var i = 0; i < n; i++) {
        f();
    }
}