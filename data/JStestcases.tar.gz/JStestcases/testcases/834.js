function(producer) {
    Promise.resolve(producer()).then().catch(() => {});
}