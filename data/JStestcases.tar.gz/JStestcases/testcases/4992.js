function() {
    var ui32 = new Uint32Array();
    for (var _strvar23 in ui32) {
        if (typeof _strvar23) {
            continue;
        }
        try {} catch (ex) {
            continue;
        } finally {}
        break;
    }
}