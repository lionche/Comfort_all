function() {
    return 'Help!';
}