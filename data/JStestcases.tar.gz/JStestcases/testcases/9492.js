function(x) {
    return this.vu_levels[x];
}