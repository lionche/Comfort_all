function(a) {
    return a != 1;
}