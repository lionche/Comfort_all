function() {
    this.a = this.b = this.c;
}