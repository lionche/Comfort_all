function* callArguments() {
    while (true) {
        yield {
            value: -12345,
            i32: "(i32.const -12345)",
            i64: "(i64.const -12345)",
            f32: `(f32.const ${Math.fround(-12345)})`,
            f64: `(f64.const -12345.0)`
        };
        yield {
            value: "0xabcdef12345678",
            i32: "(i32.const 0)",
            i64: "(i64.const 0xabcdef12345678)",
            f32: "(f32.const 0)",
            f64: "(f64.const 0)"
        };
        yield {
            value: Math.PI,
            i32: `(i32.const ${Math.PI|0})`,
            i64: `(i64.const ${Math.PI|0})`,
            f32: `(f32.const ${Math.fround(Math.PI)})`,
            f64: `(f64.const ${Math.PI})`
        };
    }
}