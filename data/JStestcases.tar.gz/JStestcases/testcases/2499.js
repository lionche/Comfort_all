function(resolve, reject) {
    reject(new Error("uncaught")); // event
}