function() {
    return {
        toString() {
            return Symbol();
        }
    }
}