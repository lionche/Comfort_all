function() {
    return (this instanceof String);
}