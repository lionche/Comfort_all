function(obj, prop, value) {
    obj[prop] = "";
}