function(x, y) {
    this.y = y;
    this.x = x;
}