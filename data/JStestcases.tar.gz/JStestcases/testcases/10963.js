function() {
    return "valueOf override throw";
}