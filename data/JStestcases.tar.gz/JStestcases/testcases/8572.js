function(a, b, i, arr) {
    return Number(a) + Number(b) * Math.pow(10, arr.length - i - 1);
}