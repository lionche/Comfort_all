function(y) {
    return y + 1;
}