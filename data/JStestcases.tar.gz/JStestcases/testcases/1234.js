function(parentObj) {
    "use strict";
    parentObj.registerC &= 0xBF;
}