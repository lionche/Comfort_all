function(parentObj) {
    "use strict";
    parentObj.registerD &= 0xFD;
}