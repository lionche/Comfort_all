function() {
    var
    let = 1, test = 2;
}