function(y, y) {
    return 3;
}