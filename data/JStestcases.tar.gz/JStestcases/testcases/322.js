function() {
    return "getFunctionString";
}