function() {
    var a = 4;
    return a >> (a = 2);
}