function(message) {
    var x = 1;
    throw (message)
    return x;
}