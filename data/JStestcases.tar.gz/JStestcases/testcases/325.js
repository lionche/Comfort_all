function() {
    var readyState = this.transport.readyState;
    if (readyState != 1) {
        this.respondToReadyState(this.transport.readyState);
    }
}