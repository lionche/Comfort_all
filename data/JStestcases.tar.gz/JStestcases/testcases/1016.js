function() {
    return this.uuidGen.generateUUID().toString();
}