function* fibonacci() {
    let x = 0;
    let y = 1;
    yield x;
    while (true) {
        yield y;
        let tmp = x;
        x = y;
        y += tmp;
    }
}