function(arg) {
    return ++arg;
}