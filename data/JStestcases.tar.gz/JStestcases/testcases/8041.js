function() {
    WeakMap.prototype.get.call(1, {});
}