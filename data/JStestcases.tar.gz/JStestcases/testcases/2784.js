function(val) {
    var iic = val + 1;

    function inner() {
        return iic++;
    }
    return inner;
}