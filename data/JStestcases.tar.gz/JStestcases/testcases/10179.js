function(v17) {
    v17.method0();
}