function() {
    SharedArrayBuffer.prototype.slice.call(1);
}