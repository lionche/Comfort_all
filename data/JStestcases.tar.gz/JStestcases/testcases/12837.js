function(decl) {
    return "eval(\'" + decl + "\')";
}