function() {
    return this === global;
}