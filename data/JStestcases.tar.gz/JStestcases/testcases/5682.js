function(parts, allowAboveRoot) {
    var up = 0;
    for (var i = parts.length - 1; i >= 0; i--) {
        var last = parts[i];
        if (last === ".") {
            parts.splice(i, 1)
        } else if (last === "..") {
            parts.splice(i, 1);
            up++
        } else if (up) {
            parts.splice(i, 1);
            up--
        }
    }
    if (allowAboveRoot) {
        for (; up--; up) {
            parts.unshift("..")
        }
    }
    return parts
}