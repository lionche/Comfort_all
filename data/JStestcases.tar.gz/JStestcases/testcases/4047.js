function(value) {
    this.value = new Function("return this.value");
    this.toString = new Function("return this.value+''");
}