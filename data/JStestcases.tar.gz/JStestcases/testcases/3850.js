function(arr, value) {
    arr[arr.length] = value;
}