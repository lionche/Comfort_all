function() {
    return this._src;
}