function(a, b, c, d) {
    if (a) {} else {}
}