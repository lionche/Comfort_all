function(a, i, v) {
    a[0] = v;
    a[i] = v;
}