function() {
    var d = new DataView(new ArrayBuffer())
    for (var $;;) {
        d.setInt8(0)
    }
}