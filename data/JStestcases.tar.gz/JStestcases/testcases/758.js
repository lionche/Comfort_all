function(num) {
    num = Math.round(num);
    var _4ab = num.toString(16);
    if (num < 16) {
        return "0" + _4ab;
    }
    return _4ab;
}