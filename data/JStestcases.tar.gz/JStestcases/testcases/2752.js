function(s, sideEffect) {
    var a = String(s);
    sideEffect(s);
    var b = String(s);
    return a + b;
}