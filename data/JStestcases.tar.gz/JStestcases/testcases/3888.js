function(t, prop, value, receiver) {
    return undefined;
}