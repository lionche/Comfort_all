function() {
    return 0;
}