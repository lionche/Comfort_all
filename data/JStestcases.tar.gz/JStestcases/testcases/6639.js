function() {
    var base = null;
    var prop = function() {
        throw new DummyError();
    };
    var expr = function() {
        throw new Test262Error("right-hand side expression evaluated");
    };
    base[prop()] ?? = expr();
}