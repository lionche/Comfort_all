function(pos, pulses) {
    if (pulses) {
        pos *= 2 * pulses;
    } else {
        pos *= 10;
    }
    var decimals = pos - Math.floor(pos);
    return (Math.floor(pos) % 2 == 0) ? decimals : 1 - decimals;
}