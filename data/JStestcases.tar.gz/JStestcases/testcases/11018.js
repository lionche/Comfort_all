function() {
    (function() {
        this.feat = "kamon beyba"
    }).apply(null);
}