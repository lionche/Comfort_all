function() {
    return () => {
        return 42;
    }
}