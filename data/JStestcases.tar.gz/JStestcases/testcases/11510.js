function(chunk, encoding, callback) {
    if (this.stream) {
        this.stream.write(chunk, encoding, callback);
    } else {
        this.once('socket', this._write.bind(this, chunk, encoding, callback));
    }
}