function() {
    var a = new Array(10);
    for (var i = 0; i < a.length; i++) {
        a[i] = i;
    }
    return a;
}