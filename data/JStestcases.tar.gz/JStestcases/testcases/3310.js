function() {
    var func4 = function(...[argArr6]) {
        for (var _i in arguments) {}
    };
}