function(val, idx, obj) {
    if (idx === 2 && val === "unconfigurable") {
        return false;
    } else {
        return true;
    }
}