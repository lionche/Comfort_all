function(fun) {
    fun()
}