function(parentObj) {
    parentObj.registerA &= 0xDF;
}