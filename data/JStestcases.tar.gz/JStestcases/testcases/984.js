function() {
    return {
        a: 1
    };
}