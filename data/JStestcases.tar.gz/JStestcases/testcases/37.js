function() {
    var l = arguments.length;
    var a = new Array(l - 3);
    a.push(arguments[0]);
    for (var i = 2; i < l - 2; i++) {
        a.push(arguments[i]);
    }
    return "[@" + arguments[l - 2] + ":" + a.join(",") + "]";
}