function() {
    return this.val;
}