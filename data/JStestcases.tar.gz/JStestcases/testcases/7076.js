function() {
    String.fromCodePoint(NaN);
}