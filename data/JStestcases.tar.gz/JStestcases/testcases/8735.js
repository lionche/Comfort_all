function() {
    eval(
        'assert.sameValue(\
      f, undefined, "Initialized binding created prior to evaluation"\
    );\
    \
    try {\
      throw null;\
    } catch (f) {if (true) function() { return 123; }}\
    \
    assert.sameValue(\
      typeof f,\
      "function",\
      "binding value is updated following evaluation"\
    );\
    assert.sameValue(f(), 123);'
    );
}