function(t) {
    return t + 1; // expected line
}