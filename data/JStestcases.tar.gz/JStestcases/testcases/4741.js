function(base, options, handler) {
    var state = {};
    this._spdyState = state;
    if (!options) options = {};
    if (!options.maxStreams) options.maxStreams = 100;
    if (!options.sinkSize) {
        options.sinkSize = 1 << 16;
    }
    if (!options.windowSize) {
        options.windowSize = 1 << 20; // 1mb
    }
    options.NPNProtocols = ['spdy/3', 'spdy/2', 'http/1.1', 'http/1.0'];
    options.ALPNProtocols = ['spdy/3', 'spdy/2', 'http/1.1', 'http/1.0'];
    state.options = options;
    state.reqHandler = handler;
    if (options.plain && !options.ssl) {
        base.call(this, handler);
    } else {
        base.call(this, options, handler);
    }
    if (!process.features.tls_npn && !process.features.tls_alpn && !options.debug && !options.plain) {
        return;
    }
}