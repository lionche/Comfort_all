function(x, y) {
    var g = function(z) {
        return Math.exp(z);
    };
    return g(x + y);
}