function(a, b) {
    a += 0x7fffffff;
    return a & b;
}