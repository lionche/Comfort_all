function() {
    var k = "captured";
    var x0 = function() {
        return "hi"
    }
    var x1 = function() {
        return function() {
            return "nested" + k
        }
    }
    var x2 = function() {
        return 1 + 2
    }
}