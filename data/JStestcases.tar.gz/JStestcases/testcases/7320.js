function(x) {
    (function() {
        return x;
    })();
}