function() {
    function test0a(o) {
        o.p = "1";
    }

    function test0b(o) {
        var sum = 0;
        for (var i = 0; i < 10; ++i) {
            sum += o.p &= 1;
            for (var j = 0; j < 10; ++j) {
                sum += o.p | 0;
                o.q = test0a(o);
            }
            sum += o.p | 0;
        }
        return sum;
    }
    return test0b({
        p: 1,
        q: 1
    });
}