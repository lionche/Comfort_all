function(a) {
    {
        return a;
    }
}