function() {
    function test() {
        if (true);
    }
    test();
}