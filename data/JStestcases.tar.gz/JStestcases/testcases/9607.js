function(a, b) {
    switch (a) {
        case b:
            break;
        default:
            break;
    }
    return b;
}