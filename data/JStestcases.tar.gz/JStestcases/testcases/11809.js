function(a) {
    a.x = 0;
    if (a.x === 0) a[1] = 0.1;
    a.x = {};
}