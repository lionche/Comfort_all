function(array) {
    var o = {};
    for (var i in array)
        o[i] = array[i];
    o.length = array.length;
    o.reduce = Array.prototype.reduce;
    return o;
}