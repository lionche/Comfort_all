function(target) {
    Object.preventExtensions(target);
    return true;
}