function(bin) {
    var r = 0;
    var sign;
    if (Number(bin.charAt(0)) == 0) {
        sign = 1;
        r = 0;
    } else {
        sign = -1;
        r = -(Math.pow(2, 31));
    }
    for (var j = 0; j < 31; j++) {
        r += Math.pow(2, j) * Number(bin.charAt(31 - j));
    }
    return r;
}