function(a) {
    return "" + this + a;
}