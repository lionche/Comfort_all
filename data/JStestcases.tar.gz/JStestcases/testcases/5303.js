function() {
    this.channel2Enabled = ((this.channel2consecutive || this.channel2totalLength > 0) && this.channel2canPlay);
    this.channel2OutputLevelSecondaryCache();
}