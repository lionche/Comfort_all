function() {
    throw String(this);
}