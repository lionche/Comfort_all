function() {
    var a = 0.1;
    while (!(a <= 1.1 && a <= 1.1))
        return true;
    return false;
}