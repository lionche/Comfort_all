function() {
    this.hello = "yay5";
    return "blah" + this.hello;
}