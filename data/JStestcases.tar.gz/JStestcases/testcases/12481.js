function() {
    this.aproperty = 1;
}