function(t, p) {
    return 1;
}