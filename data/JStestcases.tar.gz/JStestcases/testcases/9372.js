function(array) {
    let result = [];
    for (let item of array) {
        result.push(Number(item));
    }
    return result;
}