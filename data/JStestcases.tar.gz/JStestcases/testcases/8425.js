function() {
    try {
        return 1;
    } finally {
        try {
            return 2;
        } finally {
            return 42;
        }
    }
}