function() {
    return 'default';
}