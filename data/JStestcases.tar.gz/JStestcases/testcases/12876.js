function() {
    return arguments.hasOwnProperty(0);
}