function() {
    new SharedArrayBuffer(7 * 1125899906842624);
}