function(a) {
    return Math.clz32(a);
}