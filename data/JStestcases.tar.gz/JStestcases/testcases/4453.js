function(x) {
    return x + x;
}