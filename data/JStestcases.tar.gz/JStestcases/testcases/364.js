function(index) {
    let controller;
    let promise = new Promise((resolve, reject) => {
        controller = {
            resolve,
            reject
        };
    });
    controller.reject("Rejection from test " + index); //Should notify rejected
    promise.catch(() => {}); //Should notify handled
    promise.catch(() => {}); //Should NOT notify
}