function(a) {
    return Object.defineProperty(a, 'x', {
        get() {
            return 1;
        }
    });
}