function(x, y, z, t) {
    return Object.seal(new Array(x, y, z, t));
}