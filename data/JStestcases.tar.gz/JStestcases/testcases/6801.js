function() {
    this.init.apply(this, arguments);
}