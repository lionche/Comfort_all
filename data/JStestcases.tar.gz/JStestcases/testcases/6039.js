function() {
    return "s2"; // expected line
}