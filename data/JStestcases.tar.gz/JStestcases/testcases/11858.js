function() {
    'hide source'
}