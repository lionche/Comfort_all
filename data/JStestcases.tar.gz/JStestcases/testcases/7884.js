function() {
    this.logs = [];
}