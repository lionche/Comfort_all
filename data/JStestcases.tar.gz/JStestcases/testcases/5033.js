function() {
    for (var index = 0x0000; index <= 0xFFFF; index++) {
        if (index < 0x4000) {
            this.memoryReader[index] = this.memoryReadNormal;
        } else if (index < 0x8000) {
            this.memoryReader[index] = this.memoryReadROM;
        } else if (index < 0x9800) {
            this.memoryReader[index] = (this.cGBC) ? this.VRAMDATAReadCGBCPU : this.VRAMDATAReadDMGCPU;
        } else if (index < 0xA000) {
            this.memoryReader[index] = (this.cGBC) ? this.VRAMCHRReadCGBCPU : this.VRAMCHRReadDMGCPU;
        } else if (index >= 0xA000 && index < 0xC000) {
            if ((this.numRAMBanks == 1 / 16 && index < 0xA200) || this.numRAMBanks >= 1) {
                if (this.cMBC7) {
                    this.memoryReader[index] = this.memoryReadMBC7;
                } else if (!this.cMBC3) {
                    this.memoryReader[index] = this.memoryReadMBC;
                } else {
                    this.memoryReader[index] = this.memoryReadMBC3;
                }
            } else {
                this.memoryReader[index] = this.memoryReadBAD;
            }
        } else if (index >= 0xC000 && index < 0xE000) {
            if (!this.cGBC || index < 0xD000) {
                this.memoryReader[index] = this.memoryReadNormal;
            } else {
                this.memoryReader[index] = this.memoryReadGBCMemory;
            }
        } else if (index >= 0xE000 && index < 0xFE00) {
            if (!this.cGBC || index < 0xF000) {
                this.memoryReader[index] = this.memoryReadECHONormal;
            } else {
                this.memoryReader[index] = this.memoryReadECHOGBCMemory;
            }
        } else if (index < 0xFEA0) {
            this.memoryReader[index] = this.memoryReadOAM;
        } else if (this.cGBC && index >= 0xFEA0 && index < 0xFF00) {
            this.memoryReader[index] = this.memoryReadNormal;
        } else if (index >= 0xFF00) {
            switch (index) {
                case 0xFF00:
                    this.memoryHighReader[0] = this.memoryReader[0xFF00] = function(parentObj, address) {
                        return 0xC0 | parentObj.memory[0xFF00]; //Top nibble returns as set.
                    }
                    break;
                case 0xFF01:
                    this.memoryHighReader[0x01] = this.memoryReader[0xFF01] = function(parentObj, address) {
                        return (parentObj.memory[0xFF02] < 0x80) ? parentObj.memory[0xFF01] : 0xFF;
                    }
                    break;
                case 0xFF02:
                    if (this.cGBC) {
                        this.memoryHighReader[0x02] = this.memoryReader[0xFF02] = function(parentObj, address) {
                            return ((parentObj.serialTimer <= 0) ? 0x7C : 0xFC) | parentObj.memory[0xFF02];
                        }
                    } else {
                        this.memoryHighReader[0x02] = this.memoryReader[0xFF02] = function(parentObj, address) {
                            return ((parentObj.serialTimer <= 0) ? 0x7E : 0xFE) | parentObj.memory[0xFF02];
                        }
                    }
                    break;
                case 0xFF04:
                    this.memoryHighReader[0x04] = this.memoryReader[0xFF04] = function(parentObj, address) {
                        parentObj.memory[0xFF04] = (parentObj.memory[0xFF04] + (parentObj.DIVTicks >> 8)) & 0xFF;
                        parentObj.DIVTicks &= 0xFF;
                        return parentObj.memory[0xFF04];
                    }
                    break;
                case 0xFF07:
                    this.memoryHighReader[0x07] = this.memoryReader[0xFF07] = function(parentObj, address) {
                        return 0xF8 | parentObj.memory[0xFF07];
                    }
                    break;
                case 0xFF0F:
                    this.memoryHighReader[0x0F] = this.memoryReader[0xFF0F] = function(parentObj, address) {
                        return 0xE0 | parentObj.interruptsRequested;
                    }
                    break;
                case 0xFF10:
                    this.memoryHighReader[0x10] = this.memoryReader[0xFF10] = function(parentObj, address) {
                        return 0x80 | parentObj.memory[0xFF10];
                    }
                    break;
                case 0xFF11:
                    this.memoryHighReader[0x11] = this.memoryReader[0xFF11] = function(parentObj, address) {
                        return 0x3F | parentObj.memory[0xFF11];
                    }
                    break;
                case 0xFF13:
                    this.memoryHighReader[0x13] = this.memoryReader[0xFF13] = this.memoryReadBAD;
                    break;
                case 0xFF14:
                    this.memoryHighReader[0x14] = this.memoryReader[0xFF14] = function(parentObj, address) {
                        return 0xBF | parentObj.memory[0xFF14];
                    }
                    break;
                case 0xFF16:
                    this.memoryHighReader[0x16] = this.memoryReader[0xFF16] = function(parentObj, address) {
                        return 0x3F | parentObj.memory[0xFF16];
                    }
                    break;
                case 0xFF18:
                    this.memoryHighReader[0x18] = this.memoryReader[0xFF18] = this.memoryReadBAD;
                    break;
                case 0xFF19:
                    this.memoryHighReader[0x19] = this.memoryReader[0xFF19] = function(parentObj, address) {
                        return 0xBF | parentObj.memory[0xFF19];
                    }
                    break;
                case 0xFF1A:
                    this.memoryHighReader[0x1A] = this.memoryReader[0xFF1A] = function(parentObj, address) {
                        return 0x7F | parentObj.memory[0xFF1A];
                    }
                    break;
                case 0xFF1B:
                    this.memoryHighReader[0x1B] = this.memoryReader[0xFF1B] = this.memoryReadBAD;
                    break;
                case 0xFF1C:
                    this.memoryHighReader[0x1C] = this.memoryReader[0xFF1C] = function(parentObj, address) {
                        return 0x9F | parentObj.memory[0xFF1C];
                    }
                    break;
                case 0xFF1D:
                    this.memoryHighReader[0x1D] = this.memoryReader[0xFF1D] = function(parentObj, address) {
                        return 0xFF;
                    }
                    break;
                case 0xFF1E:
                    this.memoryHighReader[0x1E] = this.memoryReader[0xFF1E] = function(parentObj, address) {
                        return 0xBF | parentObj.memory[0xFF1E];
                    }
                    break;
                case 0xFF1F:
                case 0xFF20:
                    this.memoryHighReader[index & 0xFF] = this.memoryReader[index] = this.memoryReadBAD;
                    break;
                case 0xFF23:
                    this.memoryHighReader[0x23] = this.memoryReader[0xFF23] = function(parentObj, address) {
                        return 0xBF | parentObj.memory[0xFF23];
                    }
                    break;
                case 0xFF26:
                    this.memoryHighReader[0x26] = this.memoryReader[0xFF26] = function(parentObj, address) {
                        parentObj.audioJIT();
                        return 0x70 | parentObj.memory[0xFF26];
                    }
                    break;
                case 0xFF27:
                case 0xFF28:
                case 0xFF29:
                case 0xFF2A:
                case 0xFF2B:
                case 0xFF2C:
                case 0xFF2D:
                case 0xFF2E:
                case 0xFF2F:
                    this.memoryHighReader[index & 0xFF] = this.memoryReader[index] = this.memoryReadBAD;
                    break;
                case 0xFF30:
                case 0xFF31:
                case 0xFF32:
                case 0xFF33:
                case 0xFF34:
                case 0xFF35:
                case 0xFF36:
                case 0xFF37:
                case 0xFF38:
                case 0xFF39:
                case 0xFF3A:
                case 0xFF3B:
                case 0xFF3C:
                case 0xFF3D:
                case 0xFF3E:
                case 0xFF3F:
                    this.memoryReader[index] = function(parentObj, address) {
                        return (parentObj.channel3canPlay) ? parentObj.memory[0xFF00 | (parentObj.channel3lastSampleLookup >> 1)] : parentObj.memory[address];
                    }
                    this.memoryHighReader[index & 0xFF] = function(parentObj, address) {
                        return (parentObj.channel3canPlay) ? parentObj.memory[0xFF00 | (parentObj.channel3lastSampleLookup >> 1)] : parentObj.memory[0xFF00 | address];
                    }
                    break;
                case 0xFF41:
                    this.memoryHighReader[0x41] = this.memoryReader[0xFF41] = function(parentObj, address) {
                        return 0x80 | parentObj.memory[0xFF41] | parentObj.modeSTAT;
                    }
                    break;
                case 0xFF42:
                    this.memoryHighReader[0x42] = this.memoryReader[0xFF42] = function(parentObj, address) {
                        return parentObj.backgroundY;
                    }
                    break;
                case 0xFF43:
                    this.memoryHighReader[0x43] = this.memoryReader[0xFF43] = function(parentObj, address) {
                        return parentObj.backgroundX;
                    }
                    break;
                case 0xFF44:
                    this.memoryHighReader[0x44] = this.memoryReader[0xFF44] = function(parentObj, address) {
                        return ((parentObj.LCDisOn) ? parentObj.memory[0xFF44] : 0);
                    }
                    break;
                case 0xFF4A:
                    this.memoryHighReader[0x4A] = this.memoryReader[0xFF4A] = function(parentObj, address) {
                        return parentObj.windowY;
                    }
                    break;
                case 0xFF4F:
                    this.memoryHighReader[0x4F] = this.memoryReader[0xFF4F] = function(parentObj, address) {
                        return parentObj.currVRAMBank;
                    }
                    break;
                case 0xFF55:
                    if (this.cGBC) {
                        this.memoryHighReader[0x55] = this.memoryReader[0xFF55] = function(parentObj, address) {
                            if (!parentObj.LCDisOn && parentObj.hdmaRunning) { //Undocumented behavior alert: HDMA becomes GDMA when LCD is off (Worms Armageddon Fix).
                                parentObj.DMAWrite((parentObj.memory[0xFF55] & 0x7F) + 1);
                                parentObj.memory[0xFF55] = 0xFF; //Transfer completed.
                                parentObj.hdmaRunning = false;
                            }
                            return parentObj.memory[0xFF55];
                        }
                    } else {
                        this.memoryReader[0xFF55] = this.memoryReadNormal;
                        this.memoryHighReader[0x55] = this.memoryHighReadNormal;
                    }
                    break;
                case 0xFF56:
                    if (this.cGBC) {
                        this.memoryHighReader[0x56] = this.memoryReader[0xFF56] = function(parentObj, address) {
                            return 0x3C | ((parentObj.memory[0xFF56] >= 0xC0) ? (0x2 | (parentObj.memory[0xFF56] & 0xC1)) : (parentObj.memory[0xFF56] & 0xC3));
                        }
                    } else {
                        this.memoryReader[0xFF56] = this.memoryReadNormal;
                        this.memoryHighReader[0x56] = this.memoryHighReadNormal;
                    }
                    break;
                case 0xFF6C:
                    if (this.cGBC) {
                        this.memoryHighReader[0x6C] = this.memoryReader[0xFF6C] = function(parentObj, address) {
                            return 0xFE | parentObj.memory[0xFF6C];
                        }
                    } else {
                        this.memoryHighReader[0x6C] = this.memoryReader[0xFF6C] = this.memoryReadBAD;
                    }
                    break;
                case 0xFF70:
                    if (this.cGBC) {
                        this.memoryHighReader[0x70] = this.memoryReader[0xFF70] = function(parentObj, address) {
                            return 0x40 | parentObj.memory[0xFF70];
                        }
                    } else {
                        this.memoryHighReader[0x70] = this.memoryReader[0xFF70] = this.memoryReadBAD;
                    }
                    break;
                case 0xFF75:
                    this.memoryHighReader[0x75] = this.memoryReader[0xFF75] = function(parentObj, address) {
                        return 0x8F | parentObj.memory[0xFF75];
                    }
                    break;
                case 0xFF76:
                case 0xFF77:
                    this.memoryHighReader[index & 0xFF] = this.memoryReader[index] = function(parentObj, address) {
                        return 0;
                    }
                    break;
                case 0xFFFF:
                    this.memoryHighReader[0xFF] = this.memoryReader[0xFFFF] = function(parentObj, address) {
                        return parentObj.interruptsEnabled;
                    }
                    break;
                default:
                    this.memoryReader[index] = this.memoryReadNormal;
                    this.memoryHighReader[index & 0xFF] = this.memoryHighReadNormal;
            }
        } else {
            this.memoryReader[index] = this.memoryReadBAD;
        }
    }
}