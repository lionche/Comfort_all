function() {
    var a;
    a <<= 1;
    a = (1 > a);
    return a;
}