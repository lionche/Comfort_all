function(other) {
    return this.x * other.x + this.y * other.y + this.z * other.z;
}