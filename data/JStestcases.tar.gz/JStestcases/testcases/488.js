function(x, y) {
    return x - y
}