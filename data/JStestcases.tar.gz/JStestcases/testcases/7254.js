function() {
    return "[SpecialPowers]";
}