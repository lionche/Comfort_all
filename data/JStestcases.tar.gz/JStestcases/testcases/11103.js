function(array, value) {
    return Array.prototype.indexOf.call(array, value) >= 0;
}