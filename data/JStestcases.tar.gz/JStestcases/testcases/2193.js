function(f) {
    function t() {
        try {
            return t();
        } catch (e) {
            return f();
        }
    }
    return t();
}