function(b) {
    return "" <= b;
}