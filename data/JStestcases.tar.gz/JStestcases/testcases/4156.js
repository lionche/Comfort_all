function() {
    var code = "foo = <x/>.(",
        obj = {};
    for (var i = 0; i < 0x10000; i++) {
        code += "0, ";
    }
    code += "0);";
    Function(code);
}