function() {
    return "42";
}