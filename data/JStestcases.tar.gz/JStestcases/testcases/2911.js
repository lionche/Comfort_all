function() {
    Object.defineProperties();
}