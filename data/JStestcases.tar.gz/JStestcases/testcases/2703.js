function(a, b) {
    "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
    return a;
}