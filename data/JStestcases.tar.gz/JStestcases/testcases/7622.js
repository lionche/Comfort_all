function() {
    function h() {}
    debugger;
    h();
}