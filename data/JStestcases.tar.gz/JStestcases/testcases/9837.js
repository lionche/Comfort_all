function(o) {
    return o.f--;
}