function(x) {
    return (!true).lastIndexOf(true.splice())
}