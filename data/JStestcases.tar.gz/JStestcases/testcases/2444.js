function() {
    "use strict";
    this.updateCore();
    if (this.emulatorTicks >= this.CPUCyclesTotal) {
        this.iterationEndRoutine();
    }
}