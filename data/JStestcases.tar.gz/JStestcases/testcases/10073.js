function(_52) {
    if (typeof _52 == "string") {}
    if (_52.target) {}
    this.labelElId = "ygtvlabelel" + this.index;
}