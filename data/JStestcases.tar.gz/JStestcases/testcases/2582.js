function(str) {
    "use strict";
    var f = eval(str);
    eval('var x = 1');
    return f;
}