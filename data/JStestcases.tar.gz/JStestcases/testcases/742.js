function(parentObj) {
    "use strict";
    parentObj.registersHL &= 0x7FFF;
}