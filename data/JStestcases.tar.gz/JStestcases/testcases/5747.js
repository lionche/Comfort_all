function* gen2() {
    1 ?
        yield :
        yield
}