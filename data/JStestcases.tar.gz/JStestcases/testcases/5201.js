function(stdlib, foreign, heap) {
    "use asm";
    var MEM32 = new stdlib.Int32Array(heap);

    function foo(i) {
        i = i | 0;
        return +MEM32[i >> 2];
    }
    return {
        foo: foo
    };
}