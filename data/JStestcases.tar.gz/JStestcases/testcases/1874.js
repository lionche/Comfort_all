function() {
    (1, Object.prototype.valueOf)();
}