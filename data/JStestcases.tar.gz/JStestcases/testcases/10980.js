function() {
    global.undefined = 42;
}