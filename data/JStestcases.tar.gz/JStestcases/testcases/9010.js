function() {
    var o = {};
    o.a = 1;
    o.b = 2;
    return o;
}