function() {
    Object.create({}, {
        prop: {
            get: null
        }
    });
}