function() {
    return !(1.1 in [1, 2]);
}