function(parentObj) {
    parentObj.registerC |= 0x20;
}