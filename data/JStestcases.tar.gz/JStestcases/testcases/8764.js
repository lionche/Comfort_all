function(a, b, c) {
    delete arguments[0];
    return a;
}