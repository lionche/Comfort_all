function() {
    this.x = arguments[0];
}