function(array, func) {
    let srcIndex = 0;
    let dstIndex = 0;
    while (srcIndex < array.length) {
        let value = array[srcIndex++];
        if (!func(value))
            array[dstIndex++] = value;
    }
    array.length = dstIndex;
}