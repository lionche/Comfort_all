function() {
    return "abcdefghijklmn" + "123456789";
}