function(b) {
    return Math.min(Infinity, b);
}