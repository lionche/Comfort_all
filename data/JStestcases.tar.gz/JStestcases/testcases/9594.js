function(val, idx, obj) {
    return new EvalError();
}