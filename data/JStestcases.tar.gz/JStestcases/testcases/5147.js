function() {
    return {
        i: 0,
        next() {
            this.next = function() {
                throw new Error("This should not be called - next should have been cached")
            }
            return {
                value: this.i++,
                done: this.i > 3
            }
        }
    }
}