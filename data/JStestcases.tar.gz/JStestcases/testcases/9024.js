function() {
    String.raw(undefined);
}