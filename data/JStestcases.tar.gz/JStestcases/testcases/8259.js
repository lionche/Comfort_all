function(notNamedName, bar) {
    this.name = notNamedName;
    this.bar = bar;
}