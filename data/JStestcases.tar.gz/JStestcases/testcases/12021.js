function() {
    "use asm";

    function f() {}
    return {
        f: f
    };
}