function(arg0, arg1) {
    this.prop0 = arg0;
    this.prop2 = arg1;
}