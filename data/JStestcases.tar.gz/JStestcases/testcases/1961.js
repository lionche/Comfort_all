function() {
    "a".startsWith(/a/);
}