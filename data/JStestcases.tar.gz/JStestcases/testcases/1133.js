function(obj) {
    Object.freeze(obj);
    return obj;
}