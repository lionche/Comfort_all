function() {
    return "VerifyArgumentsObject";
}