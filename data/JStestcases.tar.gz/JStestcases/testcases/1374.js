function() {
    return 1 // B26
    ; // B27
}