function(headers) {
    this._validateHeaders(headers);
    for (var name in headers) {
        if (name[0] !== ':') {
            this.headers[name] = headers[name];
        }
    }
    var self = this;
    this.stream.on('headers', function(headers) {
        self._lastHeadersSeen = headers;
    });
}