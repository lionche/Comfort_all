function() {
    (0, eval)("function() {}");
}