function(a) {
    return "x" // Break 2.
    ; // Break 3.
}