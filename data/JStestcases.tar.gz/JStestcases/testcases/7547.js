function(a, b, c) {
    return String.prototype.indexOf.apply(a, [b, c]);
}