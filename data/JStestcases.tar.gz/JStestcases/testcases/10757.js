function(obj, name) {
    return obj[name];
}