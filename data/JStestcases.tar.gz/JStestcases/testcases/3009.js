function(f) {
    var a = f();
    var b = f();
    return a() + b();
}