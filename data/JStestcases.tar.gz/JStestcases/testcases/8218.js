function() {
    return "ownAccessorProperty";
}