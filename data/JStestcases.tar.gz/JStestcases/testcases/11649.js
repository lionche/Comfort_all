function(parentObj) {
    "use strict";
    parentObj.registersHL = (parentObj.registerD << 8) | (parentObj.registersHL & 0xFF);
}