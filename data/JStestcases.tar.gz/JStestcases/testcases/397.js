function() {
    "use asm";

    function __f_20() {
        if (1) {
            {
                {
                    return 1;
                }
            }
        }
        return 0;
    }
    return {
        __f_20: __f_20
    };
}