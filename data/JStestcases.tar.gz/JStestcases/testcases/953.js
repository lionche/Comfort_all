function() {
    this.a = "a";
}