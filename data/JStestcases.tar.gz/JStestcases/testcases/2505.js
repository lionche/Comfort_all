function() {
    const obj = {
        prop: 'test'
    };
    Symbol.prototype.description.call(obj);
}