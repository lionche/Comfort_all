function() {
    eval("'use strict';function(arguments) { }");
}