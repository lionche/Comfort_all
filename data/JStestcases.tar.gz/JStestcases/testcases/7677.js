function() {
    var re = /test/g;
    var s = '\n\r\\';
}