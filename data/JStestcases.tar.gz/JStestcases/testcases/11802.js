function(target, key) {
    var enumerable = true;
    if (key === "a") {
        enumerable = false;
    }
    return {
        configurable: true,
        enumerable: enumerable,
        value: 42,
        writable: true
    };
}