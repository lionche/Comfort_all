function() {
    eval('var arguments;');
}