function() {
    return 42;
}