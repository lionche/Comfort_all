function(stdlib, foreign, heap, offset) {
    "use asm";
    var MEM8 = new stdlib.Int8Array(heap, offset);
    var MEM16 = new stdlib.Int16Array(heap, offset);
    var MEM32 = new stdlib.Int32Array(heap, offset);
    var MEMU8 = new stdlib.Uint8Array(heap, offset);
    var MEMU16 = new stdlib.Uint16Array(heap, offset);
    var MEMU32 = new stdlib.Uint32Array(heap, offset);
    var exchange = stdlib.Atomics.exchange;
    var fround = stdlib.Math.fround;

    function exchangei8(i, x) {
        i = i | 0;
        x = x | 0;
        return exchange(MEM8, i, x) | 0;
    }

    function exchangei16(i, x) {
        i = i | 0;
        x = x | 0;
        return exchange(MEM16, i, x) | 0;
    }

    function exchangei32(i, x) {
        i = i | 0;
        x = x | 0;
        return exchange(MEM32, i, x) | 0;
    }

    function exchangeu8(i, x) {
        i = i | 0;
        x = x >>> 0;
        return exchange(MEMU8, i, x) >>> 0;
    }

    function exchangeu16(i, x) {
        i = i | 0;
        x = x >>> 0;
        return exchange(MEMU16, i, x) >>> 0;
    }

    function exchangeu32(i, x) {
        i = i | 0;
        x = x >>> 0;
        return exchange(MEMU32, i, x) >>> 0;
    }
    return {
        exchangei8: exchangei8,
        exchangei16: exchangei16,
        exchangei32: exchangei32,
        exchangeu8: exchangeu8,
        exchangeu16: exchangeu16,
        exchangeu32: exchangeu32,
    };
}