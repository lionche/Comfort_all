function() {
    return [, {}];
}