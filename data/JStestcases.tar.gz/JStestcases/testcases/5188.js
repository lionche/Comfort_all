function(name) {
    this.name = name;
}