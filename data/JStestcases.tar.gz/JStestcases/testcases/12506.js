function() {
    new [].concat();
}