function(o) {
    var v = 0;
    for (var i = 0; i < 10; i++) {
        var a = o.x;
        o = o.y;
        var b = o.x;
        v += a + b;
    }
    return v;
}