function(_59d) {
    if (this.options[_59d + "Internal"]) {
        this.options[_59d + "Internal"](this);
    }
    if (this.options[_59d]) {
        this.options[_59d](this);
    }
}