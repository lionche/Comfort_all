function() {
    eval("f();");
}