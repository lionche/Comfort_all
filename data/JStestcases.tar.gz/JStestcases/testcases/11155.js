function(func) {
    return {
        a: 10,
        b: {
            1: 100,
            2: 200
        },
        c: "hello",
        d: null
    };
}