function(value) {
    throw value + 1;
}