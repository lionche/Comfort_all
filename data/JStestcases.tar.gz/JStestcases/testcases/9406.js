function() {
    var j = JSON();
}