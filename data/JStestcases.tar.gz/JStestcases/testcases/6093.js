function() {
    this.res = "";
}