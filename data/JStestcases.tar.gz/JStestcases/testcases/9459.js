function(i, j) {
    this[i][j] = Math.exp(this[i][j]);
}