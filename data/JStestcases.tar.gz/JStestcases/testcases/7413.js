function() {
    return eval("(" + arguments[0].responseText + ")");
}