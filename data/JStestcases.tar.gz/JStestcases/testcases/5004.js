function() {
    return 'str';
}