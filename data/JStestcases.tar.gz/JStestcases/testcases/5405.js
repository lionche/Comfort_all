function(condition, name, passString, failString) {
    this.heartbeatCallback();
    let diag = this.repr(condition) + " was " + !!condition + ", expected true";
    this.addTest(condition, name, passString, failString, diag);
}