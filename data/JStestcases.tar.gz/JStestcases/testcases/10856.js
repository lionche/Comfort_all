function() {
    eval("'use strict'; function(param1, param2, param1) { }");
}