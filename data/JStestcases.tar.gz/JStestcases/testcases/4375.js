function(buffer) {
    var ratioWeight = this.ratioWeightWidthPass;
    var weight = 0;
    var amountToNext = 0;
    var actualPosition = 0;
    var currentPosition = 0;
    var line = 0;
    var pixelOffset = 0;
    var outputOffset = 0;
    var nextLineOffsetOriginalWidth = this.originalWidthMultipliedByChannels - 2;
    var nextLineOffsetTargetWidth = this.targetWidthMultipliedByChannels - 2;
    var output = this.outputWidthWorkBench;
    var outputBuffer = this.widthBuffer;
    do {
        for (line = 0; line < this.originalHeightMultipliedByChannels;) {
            output[line++] = 0;
            output[line++] = 0;
            output[line++] = 0;
        }
        weight = ratioWeight;
        do {
            amountToNext = 1 + actualPosition - currentPosition;
            if (weight >= amountToNext) {
                for (line = 0, pixelOffset = actualPosition; line < this.originalHeightMultipliedByChannels; pixelOffset += nextLineOffsetOriginalWidth) {
                    output[line++] += buffer[pixelOffset++] * amountToNext;
                    output[line++] += buffer[pixelOffset++] * amountToNext;
                    output[line++] += buffer[pixelOffset] * amountToNext;
                }
                currentPosition = actualPosition = actualPosition + 3;
                weight -= amountToNext;
            } else {
                for (line = 0, pixelOffset = actualPosition; line < this.originalHeightMultipliedByChannels; pixelOffset += nextLineOffsetOriginalWidth) {
                    output[line++] += buffer[pixelOffset++] * weight;
                    output[line++] += buffer[pixelOffset++] * weight;
                    output[line++] += buffer[pixelOffset] * weight;
                }
                currentPosition += weight;
                break;
            }
        } while (weight > 0 && actualPosition < this.originalWidthMultipliedByChannels);
        for (line = 0, pixelOffset = outputOffset; line < this.originalHeightMultipliedByChannels; pixelOffset += nextLineOffsetTargetWidth) {
            outputBuffer[pixelOffset++] = output[line++] / ratioWeight;
            outputBuffer[pixelOffset++] = output[line++] / ratioWeight;
            outputBuffer[pixelOffset] = output[line++] / ratioWeight;
        }
        outputOffset += 3;
    } while (outputOffset < this.targetWidthMultipliedByChannels);
    return outputBuffer;
}