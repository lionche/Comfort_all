function(w) { // rotate 4-byte word w left by one byte
    w[4] = w[0];
    for (var i = 0; i < 4; i++) w[i] = w[i + 1];
    return w;
}