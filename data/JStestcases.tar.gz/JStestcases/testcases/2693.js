function(arg1) {
    return 2010;
}