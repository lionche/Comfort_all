function(flag) {
    ((flag || (Math.max(-0, 0))) == 0)
}