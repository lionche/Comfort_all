function() {
    Symbol.keyFor([]);
}