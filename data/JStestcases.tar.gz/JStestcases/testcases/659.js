function() {
    Set.prototype.clear.call(Set.prototype);
}