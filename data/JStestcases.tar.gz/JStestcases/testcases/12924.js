function() {
    throw 1
}