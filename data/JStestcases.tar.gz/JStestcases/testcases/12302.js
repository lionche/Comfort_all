function(x) {
    return (x < 0);
}