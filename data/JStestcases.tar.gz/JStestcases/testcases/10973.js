function() {
    var yield = 1;
}