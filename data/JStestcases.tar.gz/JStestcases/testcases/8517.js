function() {
    return 45;
}