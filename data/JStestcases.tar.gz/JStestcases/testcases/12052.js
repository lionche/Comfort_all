function(a) {
    return a !== false;
}