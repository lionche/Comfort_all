function(parentObj, address) {
    "use strict";
    return parentObj.memory[address - 0x2000];
}