function() {
    return 'hello'
}