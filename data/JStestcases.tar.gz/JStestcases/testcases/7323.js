function(val, idx, obj) {
    return undefined === val && idx === 1;
}