function() {
    return Object.getOwnPropertyDescriptor(arguments, 1);
}