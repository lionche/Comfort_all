function* g1() {
    yield;
}