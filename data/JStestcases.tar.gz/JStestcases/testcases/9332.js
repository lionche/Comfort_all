function(id) {
    this.prop = id;
}