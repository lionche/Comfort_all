function(a) {
    return a.foo;
}