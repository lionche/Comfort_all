function(obj, value) {
    if (obj.setterProperty = value) {
        return 333;
    } else {
        return 444;
    }
}