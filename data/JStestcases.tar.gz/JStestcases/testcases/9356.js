function() {
    return 4;
}