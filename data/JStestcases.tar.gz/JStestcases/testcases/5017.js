function(num) {
    return num.v;
}