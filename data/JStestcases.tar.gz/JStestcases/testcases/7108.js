function(arg1, arg2) {
    if (!arg1) arg1 = 0;
    if (!arg2) arg2 = 0;
    this.a = arg1;
    this.b = arg1;
}