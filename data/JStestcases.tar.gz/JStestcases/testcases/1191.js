function() {
    this.nonInlineable();
}