function() {
    for (var a = 0.1; a == 0.1 || a == 0.1;)
        return true;
    return false;
}