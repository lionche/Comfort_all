function(a, b) {
    return [a.f, b.f, a == b];
}