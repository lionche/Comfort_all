function(parentObj) {
    "use strict";
    parentObj.registerB |= 0x80;
}