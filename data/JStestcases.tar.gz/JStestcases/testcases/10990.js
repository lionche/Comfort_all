function() {
    var ary = new Array(2);
    ary.reverse();
    ary.push(1);
}