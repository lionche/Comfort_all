function() {
    return "tcb { " + this.task + "@" + this.state + " }";
}