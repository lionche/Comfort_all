function() {
    return "$$";
}