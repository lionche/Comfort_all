function() {
    var $ = $()
}