function(buffer) {
    var minDb = -120;
    var minMag = Math.pow(10.0, minDb / 20.0);
    var log = Math.log;
    var max = Math.max;
    var result = Array(buffer.length);
    for (var i = 0; i < buffer.length; i++) {
        result[i] = 20.0 * log(max(buffer[i], minMag));
    }
    return result;
}