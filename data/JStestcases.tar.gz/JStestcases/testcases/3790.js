function() {
    function* boo() {
        debugger;
        yield;
    }
    var gen = boo();
    gen.next();
    gen.next();
}