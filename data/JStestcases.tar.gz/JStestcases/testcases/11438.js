function(scope) {
    scope.counter = scope.counter + 1;
}