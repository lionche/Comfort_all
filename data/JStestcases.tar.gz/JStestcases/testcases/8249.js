function(parentObj) {
    "use strict";
    parentObj.registerB &= 0xFB;
}