function(chr) {
    return (chr >= 33 && chr <= 47) ||
        (chr >= 58 && chr <= 64) ||
        (chr >= 91 && chr <= 96) ||
        (chr >= 123 && chr <= 126);
}