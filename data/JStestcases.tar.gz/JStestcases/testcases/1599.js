function() {
    RegExp("\\3", "u");
}