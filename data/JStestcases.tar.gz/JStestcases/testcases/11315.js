function() {
    this.field = "baz";
}