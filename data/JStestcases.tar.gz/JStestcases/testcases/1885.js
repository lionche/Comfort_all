function() {
    return [, , , , , , 5.5];
}