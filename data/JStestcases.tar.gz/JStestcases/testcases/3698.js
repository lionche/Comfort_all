function() {
    let p = Promise.resolve(true)
        .then(() => {
            try {
                throw new Error('error for noRejection9');
            } catch (err) {}
        });
}