function(i) {
    var k = 0;
    while (i--) {
        k++;
    }
    return k;
}