function() {
    var d = {};
    var a = [arguments];
}