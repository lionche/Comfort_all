function(address, data) {
    if (this.channel3canPlay) {
        this.audioJIT();
    }
    this.memory[0xFF30 | address] = data;
    address <<= 1;
    this.channel3PCM[address] = data >> 4;
    this.channel3PCM[address | 1] = data & 0xF;
}