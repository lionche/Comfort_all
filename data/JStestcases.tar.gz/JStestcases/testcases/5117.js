function() {
    "use asm";

    function caller() {
        var i = 0;
        for (;
            (i | 0) < 10; i = (i + 1) | 0) {
            continue;
        }
        return 4711;
    }
    return {
        caller: caller
    };
}