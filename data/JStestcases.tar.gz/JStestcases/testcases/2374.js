function(operand, op) {
    return "{\n" +
        "    " + operand + " = I;\n" +
        "    let tmp = " + op + op + operand + ";\n" +
        "    if (" + operand + " !== Number(I) " + op + " 1)\n" +
        "        throw Error('" + op + op + operand + " case 1 for '+uneval(I));\n" +
        "    if (tmp !== " + operand + ")\n" +
        "        throw Error('" + op + op + operand + " case 2 for '+uneval(I));\n" +
        "}\n";
}