function(n) {
    if (this.isTransparent) {
        return 0;
    }
    var o = this.options;
    if (o.compact && o.blend) {
        var smBlendedMarginSizes = [1, 0];
        return smBlendedMarginSizes[n];
    } else if (o.compact) {
        var compactMarginSizes = [2, 1];
        return compactMarginSizes[n];
    } else if (o.blend) {
        var blendedMarginSizes = [3, 2, 1, 0];
        return blendedMarginSizes[n];
    } else {
        var marginSizes = [5, 3, 2, 1];
        return marginSizes[n];
    }
}