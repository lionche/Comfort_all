function(a) {
    return a[0] = a[0] = 1;
}