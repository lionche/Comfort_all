function(a, length) {
    for (let i = 0; i < length; ++i) {
        a.push(length - i);
    }
}