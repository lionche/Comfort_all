function(value, index, array) {
    return "";
}