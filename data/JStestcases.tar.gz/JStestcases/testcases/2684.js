function() {
    return (this.x + this.y) + " (overwritten)";
}