function() {
    "use asm";

    function __f_20() {
        var __v_23 = -83;
        var __v_25 = 28;
        return ((__v_23 | 0) % (__v_25 | 0)) | 0;
    }
    return {
        __f_20: __f_20
    };
}