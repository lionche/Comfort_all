function(a) {
    return typeof a === "undefined";
}