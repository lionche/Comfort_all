function() {
    return Promise.reject(Error("caught reject"));
}