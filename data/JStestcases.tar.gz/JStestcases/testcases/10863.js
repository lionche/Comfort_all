function() {
    JSON.parse('\u202f1');
}