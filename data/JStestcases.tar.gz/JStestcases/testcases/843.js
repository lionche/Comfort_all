function() {
    return [, undefined, , ];
}