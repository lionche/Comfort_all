function() {
    return [{
        a: 77
    }];
}