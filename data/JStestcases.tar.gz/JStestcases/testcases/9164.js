function() {
    new Promise(function promiseUncaught() {
        throw new Error();
    });
}