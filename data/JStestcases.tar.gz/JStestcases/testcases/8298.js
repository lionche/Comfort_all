function() {
    eval("function foo({x:abc.d}) {}");
}