function(a, b) {
    return !exports.eq(a, b);
}