function(b) {
    return Math.max(true, b);
}