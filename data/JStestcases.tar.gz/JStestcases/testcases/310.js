function(value) {
    this.classname = value + "";
    this.type = typeof value;
    return this;
}