function(template, A) {
    var n = 0,
        result = "",
        vl;
    for (var i = 0; i < template.length; i++) {
        var ch = template.charAt(i);
        if (ch == "s" || ch == "S") {
            vl = A[n++] >>> 0;
            result += String.fromCharCode(vl & 0xffff);
        } else if (ch == "l" || ch == "L") { // XXX endian
            vl = A[n++] >>> 0;
            result += String.fromCharCode(vl & 0xffff, vl >> 16);
        } else if (ch == "=") {
            result += String(A[n++]);
        }
    }
    return result;
}