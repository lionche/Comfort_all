function() {
    Function.prototype.call.call(undefined, {});
}