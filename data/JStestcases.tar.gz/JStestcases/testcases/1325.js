function() {
    var x = 1;
    debugger;
    x = 2;
    return x;
}