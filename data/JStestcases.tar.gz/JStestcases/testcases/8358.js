function(sign_bit,
    exponent_bits,
    mantissa_23_bits,
    mantissa_29_bits) {
    this.sign_bit = sign_bit & 1;
    this.exponent_bits = exponent_bits & ((1 << 11) - 1);
    this.mantissa_23_bits = mantissa_23_bits & ((1 << 23) - 1);
    this.mantissa_29_bits = mantissa_29_bits & ((1 << 29) - 1);
}