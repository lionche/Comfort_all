function() {
    return 1 >> Boolean.constructor + 1;
}