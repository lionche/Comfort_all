function() {
    var t = this;
    var filt = function(name) {
        return t.getPropertyDescriptor(name).enumerable;
    };
    return this.getPropertyNames().filter(filt);
}