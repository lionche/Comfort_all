function(object) {
    return "{" +
        exports.object.keys(object)
        .map(function(key) {
            return exports.enquote(key) + ": " +
                exports.repr(object[key]);
        }).join(", ") +
        "}";
}