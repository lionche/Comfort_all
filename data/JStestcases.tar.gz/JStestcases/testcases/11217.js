function() {
    "use asm";

    function main() {
        if (2147483658) { // 2^31 + 10
            return 231;
        }
        return 0;
    }
    return {
        caller: main
    };
}