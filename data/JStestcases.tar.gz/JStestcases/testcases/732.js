function(array, sum) {
    sum += array[0];
    sum += array[1];
    sum += array[2];
    return sum;
}