function() {
    ''.normalize('invalid');
}