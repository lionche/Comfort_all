function() {
    return [+0, false].indexOf(-(4 / 3));
}