function(o) {
    return o.foo1;
}