function() {
    (function() {
        return true ? true : x;
    })();
    var x;
}