function() {
    String.fromCodePoint(3.14);
}