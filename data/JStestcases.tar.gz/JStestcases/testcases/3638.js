function() {
    for (let v; v;) {
        let x;
    }
}