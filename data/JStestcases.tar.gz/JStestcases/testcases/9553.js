function() {
    throw "";
}