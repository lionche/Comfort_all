function(a, b = a) {
    function a() {}

    function $() {}
    eval("")
}