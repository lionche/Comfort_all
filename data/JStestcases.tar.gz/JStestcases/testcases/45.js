function(a) {
    throw ReferenceError("bar");
}