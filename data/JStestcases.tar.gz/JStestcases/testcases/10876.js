function() {
    String.prototype.trimRight.call(null);
}