function() {
    var m = new Map();
    m.values.call(new WeakMap());
}