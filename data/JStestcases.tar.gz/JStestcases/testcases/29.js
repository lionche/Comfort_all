function(w) {
    try {
        'random_prop' in w;
        return true;
    } catch (e) {
        return false;
    }
}