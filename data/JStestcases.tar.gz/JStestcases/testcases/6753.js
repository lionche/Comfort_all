function(o) {
    this.pCount = 0;
    for (var p in o) {
        this.pCount++;
        if (!isNaN(p)) {
            eval("this[" + p + "] = o[" + p + "]");
        } else {
            eval("this." + p + " = o[" + p + "]");
        }
    }
}