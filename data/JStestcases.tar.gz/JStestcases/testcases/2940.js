function(aRequest) {
    this.command_id = this.getCommandId();
    this.sendAsync("addCookie", {
            cookie: aRequest.parameters.cookie
        },
        this.command_id);
}