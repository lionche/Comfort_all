function(object) {
    return (object.x - object.y) + " (original)";
}