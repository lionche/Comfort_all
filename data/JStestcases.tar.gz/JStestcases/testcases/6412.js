function() {
    do
        try {} catch (o) {}
    while (false) {}
    return true;
}