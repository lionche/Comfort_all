function(val, idx, obj) {
    return (idx === 5) && (val === "abc");
}