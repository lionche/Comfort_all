function() {
    return {
        foo: []
    };
}