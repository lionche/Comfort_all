function() {
    var arr = [1, 2];
    delete arr[0];
    return !(0 in arr);
}