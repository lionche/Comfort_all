function() {
    RegExp(")", "u");
}