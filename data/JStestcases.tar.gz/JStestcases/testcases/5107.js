function(o, p, v) {
    "use strict";
    return Reflect.set(o, p, v)
}