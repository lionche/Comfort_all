function() {
    return this.toRGBString();
}