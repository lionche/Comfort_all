function(resolve) {
    resolve('hello');
}