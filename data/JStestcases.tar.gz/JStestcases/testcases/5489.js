function() {
    return 'a'
}