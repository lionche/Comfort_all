function() {
    return arguments[2][arguments[1]] === arguments[0];
}