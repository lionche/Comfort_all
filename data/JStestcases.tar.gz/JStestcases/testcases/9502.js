function() {
    if (typeof this.openRTC == "function" && this.cTIMER) {
        var rtcData = this.openRTC(this.name);
        var index = 0;
        this.lastIteration = rtcData[index++];
        this.RTCisLatched = rtcData[index++];
        this.latchedSeconds = rtcData[index++];
        this.latchedMinutes = rtcData[index++];
        this.latchedHours = rtcData[index++];
        this.latchedLDays = rtcData[index++];
        this.latchedHDays = rtcData[index++];
        this.RTCSeconds = rtcData[index++];
        this.RTCMinutes = rtcData[index++];
        this.RTCHours = rtcData[index++];
        this.RTCDays = rtcData[index++];
        this.RTCDayOverFlow = rtcData[index++];
        this.RTCHALT = rtcData[index];
    }
}