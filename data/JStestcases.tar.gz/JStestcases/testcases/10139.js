function() {
    return 12;
}