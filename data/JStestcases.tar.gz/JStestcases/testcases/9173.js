function() {
    Promise.resolve.call(true, []);
}