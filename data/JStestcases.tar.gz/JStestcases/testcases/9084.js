function() {
    if (this.actualScanLine < 144 && this.modeSTAT == 3) {
        if (this.midScanlineOffset == -1) {
            this.midScanlineOffset = this.backgroundX & 0x7;
        }
        if (this.LCDTicks >= 82) {
            this.pixelEnd = this.LCDTicks - 74;
            this.pixelEnd = Math.min(this.pixelEnd - this.midScanlineOffset - (this.pixelEnd % 0x8), 160);
            if (this.bgEnabled) {
                this.pixelStart = this.lastUnrenderedLine * 160;
                this.BGLayerRender(this.lastUnrenderedLine);
                this.WindowLayerRender(this.lastUnrenderedLine);
            } else {
                var pixelLine = (this.lastUnrenderedLine * 160) + this.pixelEnd;
                var defaultColor = (this.cGBC || this.colorizedGBPalettes) ? 0xF8F8F8 : 0xEFFFDE;
                for (var pixelPosition = (this.lastUnrenderedLine * 160) + this.currentX; pixelPosition < pixelLine; pixelPosition++) {
                    this.frameBuffer[pixelPosition] = defaultColor;
                }
            }
            this.currentX = this.pixelEnd;
        }
    }
}