function(p) {
    return p.cdr.cdr.car;
}