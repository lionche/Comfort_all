function(prevVal, curVal, idx, obj) {
    return 1;
}