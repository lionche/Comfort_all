function(a, l) {
    a.length = l;
}