function(window, zoom) {
    this._getMUDV(window).textZoom = zoom;
}