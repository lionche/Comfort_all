function() {
    var foo = 1;
    eval('foo = 2');
    return foo;
}