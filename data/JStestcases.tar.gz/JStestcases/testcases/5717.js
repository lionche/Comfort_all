function(a, i) {
    return a[i] + 0.5;
}