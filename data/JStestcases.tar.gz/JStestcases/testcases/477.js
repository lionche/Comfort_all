function() {
    eval(
        'let f = 123;\
    init = f;switch (1) {' +
        '  default:' +
        '    function() {  }' +
        '}\
    after = f;'
    );
}