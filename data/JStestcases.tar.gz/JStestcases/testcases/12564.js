function() {
    throw "Exception thrown by toString";
}