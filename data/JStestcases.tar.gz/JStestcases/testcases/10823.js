function() {
    Object.defineProperty(this, "foo", {
        value: "new prop"
    });
    return "old prop";
}