function(p) {
    return p.car.cdr;
}