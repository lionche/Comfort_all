function() {
    "".indexOf("", {
        valueOf: null,
        toString: null
    });
}