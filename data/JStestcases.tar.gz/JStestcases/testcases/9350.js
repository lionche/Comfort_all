function(obj) {
    try {
        obj(this);
    } catch (e) {
        this.traceback(e);
    }
}