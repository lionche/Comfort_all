function() {
    RegExp("[a-\\S]", "u");
}