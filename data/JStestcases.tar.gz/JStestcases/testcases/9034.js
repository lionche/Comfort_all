function() {
    return "Lorem ipsum dolor sit amet, consectetur adipiscing elit." +
        "Nam vulputate metus est. Maecenas quis pellentesque eros," +
        "ac mattis augue. Nam porta purus vitae tincidunt blandit." +
        "Aliquam lacus dui, blandit id consectetur id, hendrerit ut" +
        "felis. Class aptent taciti sociosqu ad litora torquent per" +
        "conubia nostra, per inceptos himenaeos. Ut posuere eros et" +
        "tempus luctus. Nullam condimentum aliquam odio, at dignissim" +
        "augue tincidunt in. Nam mattis vitae mauris eget dictum." +
        "Nam accumsan dignissim turpis a turpis duis.";
}