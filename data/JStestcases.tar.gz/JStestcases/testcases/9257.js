function(x) {
    "use asm";
    var y = x.Math.fround;

    function foo() {}
    return {
        foo: foo
    };
}