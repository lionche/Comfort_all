function() {
    Object.is();
}