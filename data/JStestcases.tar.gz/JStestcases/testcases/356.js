function() {
    "use strict";
    if (this.channel2CachedDuty[this.channel2DutyTracker]) {
        this.channel2currentSampleLeftTrimary = this.channel2currentSampleLeftSecondary;
        this.channel2currentSampleRightTrimary = this.channel2currentSampleRightSecondary;
    } else {
        this.channel2currentSampleLeftTrimary = 0;
        this.channel2currentSampleRightTrimary = 0;
    }
    this.mixerOutputLevelCache();
}