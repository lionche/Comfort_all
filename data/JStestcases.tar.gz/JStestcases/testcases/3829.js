function(val) {
    return (val >>> 0) >>> 1;
}