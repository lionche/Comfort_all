function(static) {
    static()
}