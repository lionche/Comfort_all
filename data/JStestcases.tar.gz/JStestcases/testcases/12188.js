function(foo = "foodef") { // 0000
    return {
        bar
    }; // 0050
    function bar() { // 0150
        console.log("test"); // 0200
    } // 0250
}