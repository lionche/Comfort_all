function(id) {
    var header = new Buffer(12);
    header.writeUInt32BE(0x80020006, 0, true); // Version and type
    header.writeUInt32BE(0x00000004, 4, true); // Length
    id.copy(header, 8, 0, 4); // ID
    return header;
}