function(aRequest) {
    let command_id = this.command_id = this.getCommandId();
    if (this.context == "chrome") {
        try {
            let el = this.curBrowser.elementManager.getKnownElement(
                aRequest.parameters.id, this.getCurrentWindow());
            el.click();
            this.sendOk(command_id);
        } catch (e) {
            this.sendError(e.message, e.code, e.stack, command_id);
        }
    } else {
        let curWindow = this.getCurrentWindow();
        let self = this;
        this.mozBrowserClose = function() {
            curWindow.removeEventListener('mozbrowserclose', self.mozBrowserClose, true);
            self.switchToGlobalMessageManager();
            self.sendError("The frame closed during the click, recovering to allow further communications", 500, null, command_id);
        };
        curWindow.addEventListener('mozbrowserclose', this.mozBrowserClose, true);
        this.sendAsync("clickElement", {
                id: aRequest.parameters.id
            },
            command_id);
    }
}