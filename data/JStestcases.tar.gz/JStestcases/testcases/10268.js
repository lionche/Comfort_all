function() {
    return '' + '<div><div><di';
}