function(oTarget, sKey) {
    return oTarget.keys();
}