function(oTarget, sKey) {
    return true;
}