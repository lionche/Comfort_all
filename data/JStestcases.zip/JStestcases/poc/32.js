function(arr) {
    let r = /a/;
    let o = {};
    arr[0].charAt(0);
    arr[1].charAt(0);
    arr[2].charAt(0);
    arr[3].charAt(0);
    arr[4].charAt(0);
    arr[5].charAt(0);
    arr[6].charAt(0);
    arr[7].charAt(0);
    arr[8].charAt(0);
    arr[8].charAt(0);
    arr[9].charAt(0);
    o.x = 'a'.match(r);
    return o;
}