function(arr, start, end) {
    for (let i = start; i < end; i++) {
        if (i === 10) {}
        arr[i] = 2.3023e-320;
    }
}