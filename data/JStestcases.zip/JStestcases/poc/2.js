function(arr, s) {
    arr[0] = 1.1;
    if (s !== null) {
        let tmp = 'a'.localeCompare(s);
    }
    arr[0] = 2.3023e-320;
}