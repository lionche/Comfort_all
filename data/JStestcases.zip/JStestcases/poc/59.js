function(arr) {
    arr[0] = 1.1;
    this[0] = {};
    arr[0] = 2.3023e-320;
}