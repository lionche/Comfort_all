function(arr, value) {
    arr[0] = value;
}