function() {
    for (var i = 0; i < 0x100000; ++i) {
        var a = new String();
    }
}