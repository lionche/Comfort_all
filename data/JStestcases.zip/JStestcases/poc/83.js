function(arr, value) {
    arr[1] = value;
    arr[0] = 2.3023e-320;
}