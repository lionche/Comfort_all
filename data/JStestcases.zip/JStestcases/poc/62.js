function() {
    var a = [1, 2, , 3];
    a[0] = 2;
    return a;
}