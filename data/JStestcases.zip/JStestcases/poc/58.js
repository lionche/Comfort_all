function() {
    let arr = [1.1];
    let i = 0;
    for (; i < 1000; i += 0.5) {
        arr[i + 0x7777] = 2.0;
    }
    arr[1001] = 35480.0;
    for (; i < 0x7777; i++) {
        arr[i] = 1234.3;
    }
}