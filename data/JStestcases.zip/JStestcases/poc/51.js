function() {
    for (var i = 0; i < ((1024 * 1024) / 0x10); i++) {
        var a = new String();
    }
}