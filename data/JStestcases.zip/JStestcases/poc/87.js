function(a, b) {
    a.b = 2;
    b.push(0);
    a.a = 0x1234;
}