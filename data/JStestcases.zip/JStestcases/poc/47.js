function(arr, index) {
    arr[0] = 1.1;
    typeof(arr[index]);
    arr[0] = 2.3023e-320;
}