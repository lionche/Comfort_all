function(v) {
    v = v | 0;
    return v | 0;
}