function() {
    let arr = new Array(1, 2, 3, 4);
    arr['a' + ''];
}