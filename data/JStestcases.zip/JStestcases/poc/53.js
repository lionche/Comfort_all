function(arr) {
    if (arr.length <= 15)
        return;
    let j = 0;
    for (let i = 0; i < 2; i++) {
        j += 0x100000;
        j + 0x7ffffff0;
    }
}