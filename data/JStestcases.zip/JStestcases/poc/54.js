function(val, l) {
    this.a = val;
    for (let i = 0; i < l; i++) {}
    this.x = 42;
    this.y = 42;
    this.z = 42;
}