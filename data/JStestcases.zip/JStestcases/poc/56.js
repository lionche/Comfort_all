function() {
    return this.s;
}