function() {
    let arr = [];
    return arr['x'];
}