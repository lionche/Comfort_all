function() {
    return 7;
}