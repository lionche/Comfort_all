function() {
    'use asm';

    function f() {}
    return f;
}