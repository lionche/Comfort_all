function() {
    for (var i = 0; i < 10; i++) {
        new Float64Array(0x1000000);
    }
}