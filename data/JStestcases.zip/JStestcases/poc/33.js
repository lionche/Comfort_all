function(o, trigger) {
    if (trigger) {
        return o.p[0];
    } else {
        return 42;
    }
}