function(target, name) {
    return true;
}