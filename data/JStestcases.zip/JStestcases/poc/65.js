function(a) {
    var x = a.shift();
    return x;
}