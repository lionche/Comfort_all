function() {
    for (let i = 0; i < 20; i++)
        new ArrayBuffer(0x2000000);
}