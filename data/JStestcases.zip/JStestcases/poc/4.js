function(str) {
    for (let i = 0; i < 200; i++) {
        let tmp = str.charCodeAt('AAAAAAAAAA' + str + 'BBBBBBBBBB');
    }
}