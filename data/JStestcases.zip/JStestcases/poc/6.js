function(obj) {
    for (let i in obj.inlinee.call({})) {}
    for (let i in obj.inlinee.call({})) {}
}