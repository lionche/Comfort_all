function(x) {
    [x, , ];
}