function() {
    new.target.x;
}