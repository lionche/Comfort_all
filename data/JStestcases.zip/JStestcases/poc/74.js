function(arr, obj) {
    arr[0] = 1.1;
    obj.x;
    arr[0] = 2.3023e-320;
}