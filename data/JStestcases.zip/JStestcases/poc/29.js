function() {
    return 0x1234567 >> 1;
}