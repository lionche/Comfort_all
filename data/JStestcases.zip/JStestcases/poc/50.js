function() {
    let tmp = [];
    tmp[0] = tmp;
    return tmp[0];
}