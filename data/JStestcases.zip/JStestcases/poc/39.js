function(arr, arr2) {
    arr[0] = 1.1;
    arr2.method(arr2[0] = {});
    arr[0] = 2.3023e-320;
}