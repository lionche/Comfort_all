function(arr, arr2) {
    arr2[0];
    arr[0] = 1.1;
    arr2.reverse();
    arr[0] = 2.3023e-320;
}