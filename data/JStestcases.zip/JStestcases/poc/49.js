function(o, c, value) {
    o.b = 1;
    class A extends c {}
    o.a = value;
}