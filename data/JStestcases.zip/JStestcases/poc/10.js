function(x_obj, arr) {
    arr[0] = 1.1;
    arr[0] = 2.3023e-320;
}