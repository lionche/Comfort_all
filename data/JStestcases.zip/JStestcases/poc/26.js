function() {
    return 0x777777777777;
}