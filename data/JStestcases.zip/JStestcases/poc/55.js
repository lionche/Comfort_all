function() {
    Array.prototype.slice.call([]);
    return 0xffffffff;
}