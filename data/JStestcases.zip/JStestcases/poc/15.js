function(a1, a2) {
    var s = a2[0];
    var t = a1[0];
    a2[0] = 0.3;
}