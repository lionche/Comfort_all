function(o) {
    return o.r.input;
}