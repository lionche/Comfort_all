function() {
    try {} catch (e) {}
    return 0x12345678;
}