function() {
    ({
        a = () => {
            let arguments;
        }
    } = 1);
    arguments.x;
}