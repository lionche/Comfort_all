function(o) {
    o[0] = 0x41414141;
}