function(ms) {
    let start = new Date();
    while (new Date() - start < ms);
}