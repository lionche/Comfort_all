function() {
    return 0xFFFFFFFC;
}