function() {
    return global.groups.oolProperty1.objProperty.fetchme;
}