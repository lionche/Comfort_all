function(x) {
    return (x << 20) | (x >>> 12);
}