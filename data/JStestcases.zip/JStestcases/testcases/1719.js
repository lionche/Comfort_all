function() {
    var x = 0;
    x -= eval('1');
    return x == -1;
}