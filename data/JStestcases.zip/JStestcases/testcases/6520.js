function(x) {
    var a = [x - 2];
    try {
        try {
            return a;
        } finally {
            a[0]++;
        }
    } finally {
        a[0]++;
    }
}