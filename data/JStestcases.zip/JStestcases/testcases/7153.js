function() {
    return Array(1);
}