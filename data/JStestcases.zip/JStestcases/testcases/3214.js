function(x, y, z) {
    return z;
}