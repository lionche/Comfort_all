function() {
    var x = 1;
    x >>>= eval('1');
    return x == 0;
}