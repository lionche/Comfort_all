function(arr, index) {
    let s4 = 0;
    for (var t = index - 1; t >= 2; t--) {
        if (t >= 5)
            s4 += 32;
        else
            s4 += 66;
        arr[s4] = 4;
    }
}