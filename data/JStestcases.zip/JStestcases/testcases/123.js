function(code) {
    (eval("(function(){" + code + "});"))();
}