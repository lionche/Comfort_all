function(x, y, z) {
    "use strict";
    return [this, arguments.length, x];
}