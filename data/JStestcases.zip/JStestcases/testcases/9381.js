function() {
    "use asm";

    function __f_20() {
        while (1) {
            break;
        }
        return 8;
    }
    return {
        __f_20: __f_20
    };
}