function() {
    String.prototype.endsWith.call(undefined, "b");
}