function() {
    var a = new Array;
    for (var i = 0; i < 100; i++) {
        a.push(i * 10.2);
    }
    var sub = -10; /**bp:stack();locals();setFrame(1);locals();setFrame(2);locals();setFrame(3);locals();setFrame(4);locals();setFrame(5);locals();**/
    for (var i = 0; i < 100; i++) {
        a[i] -= sub;
    }
    return a.length;
}