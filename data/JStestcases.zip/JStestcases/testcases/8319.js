function(b) {
    var init;
    init();
}