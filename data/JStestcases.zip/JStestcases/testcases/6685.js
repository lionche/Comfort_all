function(options) {
    this.options = Object.extend({
        canvasHeight: 100,
        canvasWidth: 100,
        pixelWidth: 2,
        pixelHeight: 2,
        renderDiffuse: false,
        renderShadows: false,
        renderHighlights: false,
        renderReflections: false,
        rayDepth: 2
    }, options || {});
    this.options.canvasHeight /= this.options.pixelHeight;
    this.options.canvasWidth /= this.options.pixelWidth;
    /* TODO: dynamically include other scripts */
}