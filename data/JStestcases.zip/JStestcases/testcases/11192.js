function() {
    var p = new Proxy(function() {
        this.foo = 1;
    }, {});
    p.__proto__ = p;
    return new p();
}