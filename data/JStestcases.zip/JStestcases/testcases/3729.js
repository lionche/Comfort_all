function(envelope) {
    this.envelope = envelope;
}