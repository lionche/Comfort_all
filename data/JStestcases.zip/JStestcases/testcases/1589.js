function() {
    var a = 1;
    return a != (a += 1);
}