function() {
    var isObject = function isObject(x) {
        return x instanceof Object && typeof x !== "function";
    };
    var compare = function compare(expected, actual) {
        if (isObject(expected)) {
            if (!isObject(actual)) return "actual is not an object";
            var expectedFieldCount = 0,
                actualFieldCount = 0;
            for (var i in expected) {
                var compareResult = compare(expected[i], actual[i]);
                if (compareResult !== true) return compareResult;
                ++expectedFieldCount;
            }
            for (var i in actual) {
                ++actualFieldCount;
            }
            if (expectedFieldCount !== actualFieldCount) {
                return "actual has different number of fields than expected";
            }
            return true;
        } else {
            if (isObject(actual)) return "actual is an object";
            if (expected === actual) return true;
            return "expected: " + expected + " actual: " + actual;
        }
    };
    var addMessage = function addMessage(baseMessage, message) {
        if (message !== undefined) {
            baseMessage += ": " + message;
        }
        return baseMessage;
    }
    return {
        areEqual: function areEqual(expected, actual, message) {
            var compareResult = compare(expected, actual);
            if (compareResult !== true) {
                throw addMessage("assert.areEqual failed: " + compareResult, message);
            }
        },
        areNotEqual: function areNotEqual(expected, actual, message) {
            var compareResult = compare(expected, actual);
            if (compareResult === true) {
                throw addMessage("assert.areNotEqual failed", message);
            }
        },
        throws: function throws(testFunction, expectedException, message) {
            var exception = null;
            try {
                testFunction();
            } catch (ex) {
                exception = ex;
            }
            if (!(exception instanceof Object && exception.constructor === expectedException)) {
                var expectedString = expectedException.toString().replace(/\n/g, "").replace(/.*function (.*)\(.*/g, "$1");
                throw addMessage("assert.throws failed: expected: " + expectedString + ", actual: " + exception, message);
            }
        },
        fail: function fail(message) {
            throw message;
        }
    }
}