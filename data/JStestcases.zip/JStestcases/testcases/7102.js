function() {
    try {
        throw 0;
    } catch (e) {
        try {
            var x = {
                a: 'hest'
            };
            x.m = function(e) {
                return x.a;
            };
        } catch (e) {}
    }
    return x;
}