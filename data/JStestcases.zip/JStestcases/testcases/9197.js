function() {
    throw "abrupt lastIndex"
}