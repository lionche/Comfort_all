function(key) {
    return this.a + key;
}