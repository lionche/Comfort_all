function(before, thunk, after) {
    before();
    try {
        var res = thunk();
        return res;
    } finally {
        after();
    }
}