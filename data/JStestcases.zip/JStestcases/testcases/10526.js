function() {
    this.b3 = false;
    this.b2 = "D";
    this.b1 = 1234;
}