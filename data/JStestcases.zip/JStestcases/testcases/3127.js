function(t) {
    var r = [];
    for (var i in t) r.push([i, t[i]]);
    return r;
}