function() {
    this[2] = {
        b: new Proxy(Function, {})
    }
}