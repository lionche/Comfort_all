function(el, attrName, attrVal) {
    var str = el.toXMLString();
    var regex = new RegExp(' (.+?):' + attrName + '="' + attrVal + '"');
    return str.match(regex)[1];
}