function(chr) {
    return (chr == 32) || (chr >= 9 && chr <= 13);
}