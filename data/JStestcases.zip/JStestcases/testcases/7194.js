function(val, idx, obj) {
    return (idx === 0) && (val === 11);
}