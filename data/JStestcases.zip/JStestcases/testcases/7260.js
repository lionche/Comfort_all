function(s) {
    return s.toString;
}