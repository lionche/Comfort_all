function() {
    var l = arguments.length;
    return l;
}