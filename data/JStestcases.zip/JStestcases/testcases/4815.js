function(b) {
    b.blah = b.blah2 = b = null;
}