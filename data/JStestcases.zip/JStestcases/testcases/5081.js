function(v) {
    v.x = 1;
}