function(a) {
    return a !== "";
}