function(a) {
    return (function() {
        return {
            a
        };
    });
}