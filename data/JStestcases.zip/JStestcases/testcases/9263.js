function(o) {
    o.x = -1;
}