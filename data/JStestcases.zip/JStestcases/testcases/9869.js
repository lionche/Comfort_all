function(parentObj) {
    "use strict";
    parentObj.registersHL &= 0xFDFF;
}