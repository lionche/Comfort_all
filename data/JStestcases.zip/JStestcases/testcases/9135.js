function() {
    return 'return x*y';
}