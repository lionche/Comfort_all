function() {
    JSON.parse("\\u0022abc\\u0022");
}