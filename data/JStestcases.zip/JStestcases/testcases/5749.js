function() {
    new Promise(1);
}