function() {
    return new RegExp("(?<\ud835\udfdathe>the)", "u");
}