function() {
    return {
        i: 0,
        next: function() {
            return {
                done: this.i == 3,
                value: this.i++
            };
        }
    };
}