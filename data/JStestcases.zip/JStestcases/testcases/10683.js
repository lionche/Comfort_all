function() {
    this.x = 1
}