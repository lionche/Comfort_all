function() {
    String.prototype.fontcolor.call(null);
}