function(o) {
    o.__defineSetter__('property', function() {});
}