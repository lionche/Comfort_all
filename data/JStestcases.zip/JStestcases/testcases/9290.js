function(parentObj) {
    parentObj.registerA = parentObj.registerD;
}