function(parentObj) {
    "use strict";
    var L = (parentObj.registersHL - 1) & 0xFF;
    parentObj.FZero = (L == 0);
    parentObj.FHalfCarry = ((L & 0xF) == 0xF);
    parentObj.FSubtract = true;
    parentObj.registersHL = (parentObj.registersHL & 0xFF00) | L;
}