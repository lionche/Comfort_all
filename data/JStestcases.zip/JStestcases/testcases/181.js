function(parentObj) {
    "use strict";
    parentObj.registerE &= 0xF7;
}