function(a) {
    'use strict';
    var local;
    (function() {
        local;
    })();
    arguments[0] = false;
    return a;
}