function() {
    var i = 0;
    try {
        i++;
    } catch (e) {
        i += 9;
        try {
            i += 2;
        } catch (e) {
            i += 3;
        } finally {
            i += 4;
            try {
                i += 5;
            } catch (e) {
                i += 6;
            } finally {
                i += 7;
            }
        }
    } finally {
        i += 8;
    }
    i += 10;
}