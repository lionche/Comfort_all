function(arg) {
    var a = arg();
    return a;
}