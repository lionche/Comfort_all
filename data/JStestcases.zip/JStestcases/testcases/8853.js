function() {
    Function("this.feat=\"in da haus\"").call(void 0);
}