function() {
    ''.matchAll(/a/i);
}