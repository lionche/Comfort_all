function() {
    "".indexOf("", {
        [Symbol.toPrimitive]: {}
    });
}