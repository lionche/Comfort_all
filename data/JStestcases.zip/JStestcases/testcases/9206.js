function() {
    return ["not primitive"];
}