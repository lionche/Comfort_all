function(parentObj, address, data) {
    if (data == 0) {
        parentObj.RTCisLatched = false;
    } else if (!parentObj.RTCisLatched) {
        parentObj.RTCisLatched = true;
        parentObj.latchedSeconds = parentObj.RTCSeconds | 0;
        parentObj.latchedMinutes = parentObj.RTCMinutes;
        parentObj.latchedHours = parentObj.RTCHours;
        parentObj.latchedLDays = (parentObj.RTCDays & 0xFF);
        parentObj.latchedHDays = parentObj.RTCDays >> 8;
    }
}