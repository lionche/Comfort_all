function() {
    throw "boom"
}