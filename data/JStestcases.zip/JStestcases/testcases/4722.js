function(a, b) {
    a == b;
}