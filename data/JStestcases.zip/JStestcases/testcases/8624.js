function(x, r) {
    x.squareTo(r);
}