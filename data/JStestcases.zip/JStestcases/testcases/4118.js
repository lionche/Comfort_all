function() {
    return RegExp("a", "igi");
}