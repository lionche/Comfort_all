function($, b = (eval("var x"))) {
    function x() {}
    eval()
}