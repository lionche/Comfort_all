function(a, rid, q) {
    for (var i = 0; i < q.length; i++) {
        if (q[i][0] == rid) {
            for (var j = 1; j < q[i].length; j++) {
                if (q[i][j] == a) {
                    if (q[i].length == 2) {
                        q.splice(i, 1);
                    } else {
                        q[i].splice(j, 1);
                    }
                    return;
                }
            }
        }
    }
}