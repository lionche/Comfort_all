function(x, y) {
    return (x.valueOf() == y.valueOf() ? 0 : (x.valueOf() > y.valueOf() ? 1 : -1));
}