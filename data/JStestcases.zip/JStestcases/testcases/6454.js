function() {
    return '0';
}