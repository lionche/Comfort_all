function() {
    return {
        value: 1,
        done: false
    };
}