function(pos) {
    return 1 - pos;
}