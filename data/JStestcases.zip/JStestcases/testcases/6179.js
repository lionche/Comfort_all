function(parentObj) {
    parentObj.registerC &= 0xF7;
}