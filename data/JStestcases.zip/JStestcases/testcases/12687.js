function() {
    return "ziggy stardust"
}