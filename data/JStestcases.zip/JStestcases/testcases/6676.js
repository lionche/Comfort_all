function() {
    return this._hasString(this.options.corners, "all", "bottom", "bl", "br");
}