function(n) {
    if (typeof n !== "number")
        return n;
    return n >= 0 ? "0x" + n.toString(16) : "-0x" + (-n).toString(16);
}