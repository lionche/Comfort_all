function(r) {
    return r.finally();
}