function() {
    new Int32Array(new ArrayBuffer(8), 3);
}