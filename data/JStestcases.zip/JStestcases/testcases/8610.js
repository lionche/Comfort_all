function() {
    var a;
    for (var i = 0; i < 1; ++i)
        a = (0x40000000 | 0) % 3;
    return a;
}