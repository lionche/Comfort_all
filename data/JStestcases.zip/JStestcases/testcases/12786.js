function(x) {
    return ["span", {}, "Body formatted ", x.name]
}