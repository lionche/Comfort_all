function(o, v) {
    o.y = v;
}