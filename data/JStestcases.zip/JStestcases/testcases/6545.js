function() {
    "use strict";
    return this === undefined;
}