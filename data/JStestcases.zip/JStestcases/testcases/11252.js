function(object, name, type) {
    this.object = object;
    this.name = name;
    this.type = type;
}