function() {
    new WeakMap([
        [1, 1]
    ]);
}