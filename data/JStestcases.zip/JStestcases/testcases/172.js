function() {
    throw 1;
}