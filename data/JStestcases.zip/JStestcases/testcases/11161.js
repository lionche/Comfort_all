function() {
    eval("function foobaz() {}")
}