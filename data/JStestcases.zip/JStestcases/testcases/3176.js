function(b) {
    return 0 < b;
}