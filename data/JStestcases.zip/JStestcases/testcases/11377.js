function() {
    "".indexOf("", {
        valueOf: 1,
        toString: 1
    });
}