function() {
    switch (1) {
        case 2147483647:
            break;
        case 2:
            break;
        case 1:
            break;
        case -2147483648:
            break;
    }
}