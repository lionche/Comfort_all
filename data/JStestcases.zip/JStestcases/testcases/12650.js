function() {
    var ary = new Array(1);
    ary.map(function(a) {});
}