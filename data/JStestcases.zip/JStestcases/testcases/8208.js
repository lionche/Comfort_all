function* gf5() {
    try {
        yield 32;
    } catch (e) {}
}