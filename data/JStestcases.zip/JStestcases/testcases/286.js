function() {
    return {
        "a": 1.5
    };
}