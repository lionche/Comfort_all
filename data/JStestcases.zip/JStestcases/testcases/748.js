function(v) {
    return v.b;
}