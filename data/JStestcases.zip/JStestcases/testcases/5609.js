function(x) {
    return x.f();
}