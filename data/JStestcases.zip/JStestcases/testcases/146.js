function(obj) {
    for (var i = 0; i < 26; i++) {
        obj["x" + i] = 0;
    }
}