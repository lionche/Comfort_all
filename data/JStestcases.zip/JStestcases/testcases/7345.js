function(parentObj) {
    parentObj.registerE = (parentObj.registerE + 1) & 0xFF;
    parentObj.FZero = (parentObj.registerE == 0);
    parentObj.FHalfCarry = ((parentObj.registerE & 0xF) == 0);
    parentObj.FSubtract = false;
}