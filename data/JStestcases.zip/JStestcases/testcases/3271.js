function(x, y, z) {
    return y + z;
}