function() {
    eval("var\u180Efoo;");
}