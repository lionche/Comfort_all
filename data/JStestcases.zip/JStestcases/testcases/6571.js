function() {
    delete this.x;
    return 5;
}