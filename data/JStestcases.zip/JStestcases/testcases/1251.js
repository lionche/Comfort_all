function(mode) {
    return (mode & 61440) === 40960;
}