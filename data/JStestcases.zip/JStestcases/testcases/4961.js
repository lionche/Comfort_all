function* makeValueGen(a, b) {
    yield a;
    yield b;
    yield b;
}