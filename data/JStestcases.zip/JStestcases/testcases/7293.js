function(stdlib, env) {
    "use asm";
    var x = env.bar | 0;
    return {
        foo: function(y) {
            return eval(1);
        }
    };
}