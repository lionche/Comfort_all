function(a) {
    return String.fromCharCode.apply(this, a);
}