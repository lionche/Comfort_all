function* g5() {
    (yield 1) ? yield 2: yield 3;
}