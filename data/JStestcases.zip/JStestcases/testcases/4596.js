function(stdlib) {
    "use asm";
    var F = stdlib.Math.fround;

    function k1() {
        return F(F(1.0e-25) + F(5.0e-25) + F(6.0e-25) + F(9.0e-25));
    }

    function k2() {
        return F(F(1.0e-20) + F(5.0e-20) + F(6.0e-20) + F(9.0e-20));
    }

    function k3() {
        return F(F(1.0e-15) + F(5.0e-15) + F(6.0e-15) + F(9.0e-15));
    }

    function k4() {
        return F(F(1.0e-10) + F(5.0e-10) + F(6.0e-10) + F(9.0e-10));
    }

    function k5() {
        return F(F(1.0e-5) + F(5.0e-5) + F(6.0e-5) + F(9.0e-5));
    }

    function k6() {
        return F(F(1.1e+0) + F(5.1e+0) + F(6.1e+0) + F(9.1e+0));
    }
    return {
        k1: k1,
        k2: k2,
        k3: k3,
        k4: k4,
        k5: k5,
        k6: k6
    };
}