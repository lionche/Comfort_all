function() {
    var a = 2;
    return a >>> --a;
}