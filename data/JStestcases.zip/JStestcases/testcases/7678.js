function(array, block, basis) {
    array = exports.array.coerce(array);
    return array.reduce.apply(array, arguments);
}