function(s1, s2) {
    return s1.toLowerCase() <= s2.toLowerCase();
}