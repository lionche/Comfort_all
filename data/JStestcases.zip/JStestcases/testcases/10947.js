function(v, i) {
    if (i === 2) {
        [].__proto__[4] = 3;
    }
    return v * v;
}