function() {
    Math.tan('') >= 0;
}