function(val, idx, obj) {
    return val === 11;
}