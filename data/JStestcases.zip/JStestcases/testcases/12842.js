function(f) {
    try {
        f();
    } catch (ex) {}
    try {
        f();
    } catch (ex) {}
}