function(parentObj) {
    parentObj.registerB |= 0x20;
}