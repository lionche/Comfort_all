function(cond) {
    if (!cond) {
        throw new Error("AssertFailed");
    }
}