function(array) {
    let ret = 0;
    for (let x of array) ret += x;
    return ret;
}