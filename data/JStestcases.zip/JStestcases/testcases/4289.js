function() {
    String.prototype.codePointAt.call(null);
}