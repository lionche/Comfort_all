function() {
    ((d, e = d) => {
        return d * e;
    })();
}