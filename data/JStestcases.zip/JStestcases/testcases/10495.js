function() {
    return "SIX";
}