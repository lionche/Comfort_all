function(b) {
    return 1.25 > b;
}