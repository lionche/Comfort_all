function() {
    String.prototype.endsWith.call(null, "b", 4);
}