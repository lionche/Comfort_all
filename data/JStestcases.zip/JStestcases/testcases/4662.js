function() {
    var a = 0;
    while (!(a == 0 || a == 0))
        return true;
    return false;
}