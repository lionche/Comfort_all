function() {
    throw "PASSED"
}