function(object, limit) {
    for (var i = 0; i < limit; i++) {}
}