function() {
    return "0";
}