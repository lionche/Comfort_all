function(form) {
    form.NHS[0].checked = false;
    form.NHS[1].checked = false;
    form.NHB[0].checked = false;
    form.NHB[1].checked = false;
}