function(b) {
    return -1 >= b;
}