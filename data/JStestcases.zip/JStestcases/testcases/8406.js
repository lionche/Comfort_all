function(x) {
    return x++;
}