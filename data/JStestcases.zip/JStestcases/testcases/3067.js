function(optimized) {
    class C {
        ['h']() {}
    }
    let h = C.prototype.h;
    h.bind();
}