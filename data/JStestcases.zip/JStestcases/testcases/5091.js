function(a) {
    a.name = 'bar';
    return a.name;
}