function(a) {
    return a;
}