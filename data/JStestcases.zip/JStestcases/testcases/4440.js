function() {
    var a = 0,
        sum = 0;
    for (var i = 0; i < 2; ++i) {
        sum -= a;
        a = {};
    }
    return sum;
}