function(x) {
    this[x] = 1;
}