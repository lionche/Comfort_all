function() {
    return this._event.target || this._event.srcElement;
}