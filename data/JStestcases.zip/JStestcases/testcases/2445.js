function(X) {
    return 0.017453 * (X);
}