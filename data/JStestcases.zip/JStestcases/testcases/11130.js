function(dtf, time) {
    return dtf.formatToParts(time).map(part => part.value).join("");
}