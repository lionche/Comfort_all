function(val, idx, obj) {
    return '[object JSON]' === Object.prototype.toString.call(obj);
}