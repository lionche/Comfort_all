function(pos) {
    return (-Math.cos(pos * Math.PI) / 2) + 0.5;
}