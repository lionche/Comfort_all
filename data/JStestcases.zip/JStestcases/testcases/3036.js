function(one) {
    var ret = [];
    ret.push(Array.prototype.pop.call(one));
    ret.push(Array.prototype.pop.call(one));
    ret.push(one.length);
    return ret;
}