function(x, y) {
    for (var i = 0; i < x.toString().length; i++) {
        var d = (x.toString()).charCodeAt(i) - (y.toString()).charCodeAt(i);
        if (d > 0) {
            return 1;
        } else {
            if (d < 0) {
                return -1;
            } else {
                continue;
            }
        }
        var d = x.length - y.length;
        if (d > 0) {
            return 1;
        } else {
            if (d < 0) {
                return -1;
            }
        }
    }
    return 0;
}