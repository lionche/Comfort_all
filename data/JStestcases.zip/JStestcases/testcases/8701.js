function(t, n, d) {
    return true;
}