function(a, b) {
    return Number(a) * Number(b);
}