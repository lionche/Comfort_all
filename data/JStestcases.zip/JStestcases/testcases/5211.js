function(parentObj) {
    "use strict";
    parentObj.registersHL = (parentObj.registerA << 8) | (parentObj.registersHL & 0xFF);
}