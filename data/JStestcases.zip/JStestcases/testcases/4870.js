function(aFunction) {
    if (!this.__tasks) {
        this.waitForExplicitFinish();
        this.__tasks = [];
    }
    this.__tasks.push(aFunction.bind(this));
}