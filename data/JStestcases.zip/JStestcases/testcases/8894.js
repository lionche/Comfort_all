function(stream, buf, type, size) {
    return 0;
}