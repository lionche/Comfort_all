function() {
    try {
        ((y = [...[]]) => {})();
    } catch (_) {} // will core dump, if not fixed,
}