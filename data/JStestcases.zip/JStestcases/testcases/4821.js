function() {
    "" + Symbol();
}