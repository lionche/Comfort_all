function() {
    return (async () => JSON.stringify([...arguments]))();
}