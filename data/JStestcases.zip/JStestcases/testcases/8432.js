function(f0, g, h, a) {
    for (var i = 0; i < 10; i++) {
        let f = f0;
        f(i, a);
        f = g;
        g = h;
    }
}