function() {
    return eval();
}