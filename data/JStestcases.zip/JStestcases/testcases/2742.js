function() {
    async function asyncFn(x) {
        return x;
    }
    return asyncFn(1);
}