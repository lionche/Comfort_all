function(parentObj) {
    parentObj.registerE &= 0xDF;
}