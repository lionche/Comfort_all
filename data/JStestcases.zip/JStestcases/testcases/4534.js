function(parentObj, address, data) {
    parentObj.currMBCRAMBank = data & 0xF;
    parentObj.currMBCRAMBankPosition = (parentObj.currMBCRAMBank << 13) - 0xA000;
}