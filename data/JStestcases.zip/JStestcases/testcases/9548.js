function() {
    try {
        String.prototype.length.x();
    } catch (e) {}
}