function(...args) {
    return Array.isArray(args);
}