function(value) {
    let y = 4;
    switch (value) {
        case 0:
            return 10;
        case 1:
            return 20;
        case 2:
            return 30;
        case 3:
            return 40;
        case 5:
            return 60;
        case 6:
            return 70;
        case y:
            return 50;
    }
    return 0;
}