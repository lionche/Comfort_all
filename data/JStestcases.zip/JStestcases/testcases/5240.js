function() {
    for (var [{
            x
        }] of [
            []
        ]) {
        return;
    }
}